# God Travel V4 — Rapport des modifications et de validation

**Date : 19 novembre 2026**  
**Base examinée :** `God_Travel_V3_Refonte_Complete.zip` fourni dans la conversation.  
**Périmètre :** React/Vite, Java/Spring Boot, sécurité des accès, présentation et tests.  
**Destination :** intégration au dépôt [kiyotaka-sudo/God_Travel_V1](https://github.com/kiyotaka-sudo/God_Travel_V1) après revue et validation CI. Aucun push GitHub n'a été réalisé.

## 1. Fonctionnalités et design

| Domaine | Amélioration V4 | Limite à connaître |
| --- | --- | --- |
| Accueil / horaires | Filtres dynamiques par itinéraire et jour ; compteur des résultats, remise à zéro, chargement progressif par groupes de quatre | Les données viennent de `/api/voyages` : aucun horaire fictif n'a été ajouté |
| Actualisation | Relecture de la liste publique de voyages chaque minute tant que l'onglet est visible | Le serveur recalcule les disponibilités à chaque réservation ; le navigateur n'est pas une source d'autorité |
| Date | Nouveau filtre fondé sur le calendrier **Africa/Douala**, sans décalage sur les départs proches de minuit | Les dates fournies par l'API doivent être valides |
| Animation hero | Effet de traînées discret, bouton pause/reprise, préférence utilisateur conservée pendant l'onglet, arrêt hors écran et dans les onglets cachés | Illustration décorative, pas une représentation GPS du bus |
| Parcours 3D | Comportement de secours si `IntersectionObserver` est indisponible ; options de mouvement réduit et de repli WebGL V3 conservées | Un audit de FPS et des tests mobiles réels restent nécessaires |
| Responsive / accessibilité | Commandes de filtres utilisables au clavier, styles de focus, retour explicite si aucun résultat, supports petits écrans, couleurs forcées et mouvement réduit | Aucune certification WCAG/Lighthouse n'est revendiquée |

## 2. Confidentialité et sécurité

1. **Billet public :** l'ancienne requête `GET /api/billets/consulter?codeBillet=...&telephone=...` devient `POST /api/billets/consulter` avec un corps JSON. Le téléphone n'est plus dans la chaîne d'URL. Validation des longueurs et du numéro de mobile sur client et serveur. La réponse ajoute `Cache-Control: no-store`.
2. **Statut de paiement :** l'ancienne requête `GET /api/paiements/monetbil/statut` devient `POST /api/paiements/monetbil/statut` avec `{ "reference": "...", "telephone": "..." }`, validation de la requête et `Cache-Control: no-store`. Le frontend a été modifié de concert.
3. **Suivi des colis :** réponse du suivi public marquée `Cache-Control: no-store`, vérification renforcée du format des téléphones.
4. **Exceptions :** les détails internes des exceptions non gérées restent dans les journaux serveur et ne sont plus retournés dans les réponses HTTP 500.
5. **JWT et désactivation :** à chaque requête, le filtre refuse d'authentifier un compte désormais désactivé, verrouillé, expiré ou supprimé, même si un ancien jeton JWT reste valide. Test de régression Java ajouté.
6. **Séparation des connexions :** l'endpoint « voyageurs » ne fournit plus une session équipe et le portail équipe ne délivre plus de session voyageur.
7. **Erreurs d'authentification :** les comptes inactifs ou verrouillés reçoivent désormais une réponse HTTP 401, sans détail technique public.
8. **Protection anti-abus initiale :** filtre par IP, 20 opérations d'authentification/minute et 90 vérifications publiques/minute par défaut, réglable via l'environnement. Réponse JSON 429 avec `Retry-After`. **Il s'agit d'un compteur local en mémoire par serveur, non d'une protection distribuée garantie.**

### Compatibilité des anciennes intégrations

Les deux anciens endpoints `GET` contenant un numéro de téléphone **ne fonctionnent plus** en V4. Si une application mobile ou un partenaire les utilisait, adapter le client aux nouveaux `POST` avant déploiement. Aucune modification SQL supplémentaire n'est requise par V4 par rapport à la V3. La migration SQL V3 reste obligatoire pour les installations plus anciennes.

## 3. Tests réellement effectués dans cette session

| Contrôle | Résultat observé | Signification |
| --- | --- | --- |
| `npm test` (Node 22) | **18/18 réussis** | 14 cas de fonctions métier + 4 vérifications statiques des contrats API / sécurité |
| Analyse syntaxique TypeScript parser des fichiers JS/JSX `src/` | **33 fichiers, zéro erreur de parsing** | Syntaxe valide à ce niveau, pas une compilation complète |
| Analyse CSS via `tinycss2` | **0 erreur de parsing CSS** | Contrôle syntaxique, pas rendu visuel ni analyse de compatibilité |
| `npm run lint` | **Non validé** | Dépendances de CLI ESLint manquantes dans cet environnement |
| `npm run build` | **Non validé** | Dépendances de CLI Vite manquantes dans cet environnement |
| `mvn test` / compilation Java | **Non exécutés** | Maven n'est pas installé dans cet environnement ; tests Java ajoutés mais non exécutés |
| MySQL, transactions concurrentes, Monetbil réel | **Non testés** | Dépendent d'une installation et d'identifiants de recette |
| Évaluation graphique réelle (navigateur, mobile, FPS, Lighthouse) | **Non mesurée** | Aucun score ou qualificatif « sans bug » n'est inventé |

La CI GitHub Actions limite ses permissions en lecture et `.github/dependabot.yml` programme une veille hebdomadaire des dépendances npm, Maven et GitHub Actions. Les mises à jour proposées doivent être évaluées et testées, elles ne sont pas appliquées automatiquement.

Les tests CI GitHub Actions `.github/workflows/ci.yml` restent l'étape suivante pour lint, build React et tests Maven. **Ne pas commercialiser avant résultats CI et recette en environnement réel.**

## 4. Points critiques restant ouverts

- Vérifier et documenter le schéma exact de signature des notifications Monetbil **avec le fournisseur** ; simuler doublons, notifications tardives, montants incorrects, interruptions réseau, remboursement, idempotence durable et rapprochement comptable. Ne pas interpréter un retour de navigateur comme un paiement confirmé.
- Tester transactions MySQL simultanées (dernier siège, expiration, webhook concurrent, annulation) et restaurations de sauvegarde. Les paiements et billets ne peuvent pas être certifiés à partir de tests statiques.
- Remplacer le limiteur local par une protection distribuée/WAF pour plusieurs instances ; auditer les proxies/IP et la confidentialité des journaux. Ajouter alertes, surveillance, rotation de secrets et un plan de réponse aux incidents.
- Auditer le maintien du JWT dans `localStorage` (risque XSS), les politiques CSP, la gestion des sessions, les dépendances et les droits des opérateurs.
- Tester l'ensemble des écrans sur de vrais navigateurs et téléphones, les lecteurs d'écran, la performance du rendu 3D et les formulaires sur réseaux lents.
- Ajouter les contacts officiels, CGV, conditions d'annulation, politique de protection des données, durées de conservation et canal d'assistance.
- Déployer séparément le frontend, l'API Java et MySQL derrière HTTPS, avec secrets protégés, sauvegardes, monitoring et conformité applicable.

## 5. Fichiers principaux modifiés

**Frontend :** `src/pages/LandingPage.jsx`, `src/components/bus/HeroBusMotion.jsx`, `src/components/bus/ScrollJourney.jsx`, `src/pages/TicketLookupPage.jsx`, `src/pages/PaymentReturnPage.jsx`, `src/api/index.js`, `src/utils/domain.js`, `src/index.css`, `tests/domain.test.js`, `tests/api-contract.test.js`.

**Backend :** `controller/BilletController.java`, `controller/PaiementController.java`, `controller/ColisController.java`, `service/BilletterieService.java`, `service/ColisService.java`, `service/AuthService.java`, `security/JwtAuthenticationFilter.java`, `security/InMemoryRateLimiter.java`, `security/PublicRateLimitFilter.java`, `exception/GlobalExceptionHandler.java`, nouvelles requêtes DTO `BilletConsultationRequest.java` et `MonetbilStatutRequest.java`, tests Java du limiteur et des jetons, `application.example.properties`.

**Documentation et exploitation :** `README.md`, `GUIDE_PUBLICATION_GITHUB.md`, `AUDIT.md`, `BACKEND_GAPS.md`, `.github/workflows/ci.yml`, `.github/dependabot.yml` et ce rapport.

**Conclusion :** cette V4 est une amélioration vérifiable de la V3, destinée à être testée et intégrée au dépôt, **pas** une certification de perfection esthétique, de sécurité totale ou d'aptitude à encaisser des paiements réels.
