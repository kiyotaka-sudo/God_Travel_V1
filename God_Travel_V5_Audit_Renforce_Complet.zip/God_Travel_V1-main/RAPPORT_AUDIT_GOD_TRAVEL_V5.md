# God Travel V5 — Audit approfondi et corrections

**Date : 19 novembre 2026**  
**Source :** archive `God_Travel_V4_Premium_Securise.zip` transmise dans la conversation.  
**Destination prévue :** dépôt `https://github.com/kiyotaka-sudo/God_Travel_V1` (aucun push effectué).  
**Statut :** version de développement durcie, **non certifiée pour la production ni pour les paiements réels**.

## 1. Modifications réellement apportées dans les fichiers

| Priorité | Périmètre | Défaut identifié | Correction V5 |
|---|---|---|---|
| Élevée | Émission GPS | Un compte `CHAUFFEUR` avec un JWT valide pouvait déclarer un autre voyage sans contrôle d'affectation | Règle métier contrôlant `AFFECTER_EQUIPAGE` et le rôle de conduite ; vérification agence + employé actif |
| Élevée | Intégrité GPS | L'API acceptait un `idBalise` sans vérification du bus correspondant | Validation de l'existence de la balise et de son rattachement à `VOYAGE.ID_BUS` via `BALISE_GPS` |
| Élevée | Confidentialité GPS | Un chef d'agence pouvait consulter les positions ou acquitter les alertes d'autres agences | Filtrage des vues GPS et contrôle d'agence avant acquittement |
| Moyenne | Valeurs GPS | Absence de bornes de validation des latitude, longitude et vitesse | Contraintes Jakarta `[-90, 90]`, `[-180, 180]`, vitesse `0..250` ; rejet des voyages annulés ou terminés |
| Moyenne | Génération d'identifiants | IDs basés sur `currentTimeMillis()` pour certains clients, GPS et alertes : collisions possibles | IDs fondés sur UUID (16 caractères hexadécimaux + préfixe), respectant `VARCHAR(20)` |
| Moyenne | Limitations anti-abus | Map par IP potentiellement grandissante en cas de nombreuses nouvelles adresses | Limite à ~10 000 fenêtres actives ; refuse de nouvelles IP à saturation ; purge les fenêtres expirées |
| Moyenne | Cohérence API | Une contrainte SQL violée pouvait être renvoyée en erreur serveur générique | Réponse HTTP `409 DATA_CONFLICT` sans divulguer les détails SQL |
| Moyenne | Surface d'attaque | Documentation OpenAPI/Swagger ouverte à des visiteurs | URLs réservées au rôle `ADMIN` et documentation désactivée par défaut dans l'exemple de configuration |
| Critique — exploitation | Base SQL | `database/schema_production.sql` contient `DROP TABLE` | Avertissements en tête du script et du README ; **ne jamais le rejouer sur des données existantes** |

**Important sur le GPS :** les nouveaux contrôles ne prouvent pas l'authenticité physique du signal. Le navigateur ou un utilisateur autorisé peut encore saisir des coordonnées arbitraires. Pour un GPS fiable, l'ingestion de télémétrie doit être authentifiée côté appareil, avec anti-rejeu, contrôles de vitesse plausible et traçabilité.

**Impact métier :** pour enregistrer un point GPS, une balise doit être créée pour le bus. Le conducteur doit être affecté dans `AFFECTER_EQUIPAGE` avec le rôle `CHAUFFEUR_PRINCIPAL` ou `CHAUFFEUR_RELAIS`. Sans ces données, le serveur refuse le pointage (comportement voulu). Les comptes `ADMIN` et `CHEF_AGENCE` conservent leurs autorisations, avec contrôle de balise et d'agence.

## 2. Vérifications vraiment exécutées

| Test | Résultat |
|---|---|
| `npm test` (Node 22) | **24/24 tests réussis** : fonctions métier existantes + contrats statiques, dont 6 contrôles statiques supplémentaires |
| Analyse du parsing JS/JSX avec TypeScript 5.8 | **33 fichiers parsés, 0 diagnostic syntaxique** |
| Analyse syntaxique CSS avec tinycss2 | **0 erreur** |
| Contrôle du nom/version `package.json` vs `package-lock.json` | **Concordants** |
| Java 17 sans dépendances Spring (classe `InMemoryRateLimiter` compilée avec annotation simulée) | **6 vérifications comportementales réussies**, y compris saturation 10 000 clés et réouverture après 60 s |
| Archive ZIP | Intégrité vérifiée après création |

### Ce qui n'a PAS été exécuté

- `npm ci`/`npm run build`/`npm run lint` **complets** : registres npm inaccessibles et dépendances non présentes en local.
- `mvn test`, compilation complète de Spring Boot et nouveaux tests JUnit : Maven et ses dépendances non installés dans l'environnement.
- Connexion réelle à MySQL/MariaDB, contrainte SQL en simultané, migrations et restauration.
- Environnement de test Monetbil (API, IPN, signature, transactions, remboursements et doublons), indisponible sans contrat et comptes de recette.
- Navigateur React rendu, Lighthouse, accessibilité par lecteur d'écran, FPS/WebGL, appareils mobiles réels et réseau lent.
- Audit de sécurité externe / test d'intrusion.

Les tests statiques ne démontrent **pas** que le backend compilera ou qu'un parcours utilisateur fonctionne de bout en bout. Les tests JUnit `GpsServiceAuthorizationTest` ont été **ajoutés** au projet mais restent à **exécuter via Maven**.

## 3. Risques majeurs encore ouverts avant publication commerciale

1. **Monetbil :** confirmer le contrat officiel exact de signature des IPN et tester leur authenticité ; les règles actuellement codées (MD5 + concaténation triée) n'ont pas été validées auprès du prestataire. Ne pas autoriser des ventes réelles sans recette paiement.
2. **Concurrence de réservations :** effectuer de véritables tests MySQL simultanés (dernier siège, confirmation/expiration, règlement tardif, annulation) et du rapprochement comptable.
3. **Secrets et sessions :** JWT en `localStorage` ; prévoir un modèle de session plus résistant aux XSS, une politique CSP et des mécanismes de rotation/révocation.
4. **Anti-abus :** limiteur mémoire mono-instance ; en production distribuée, utiliser une passerelle/WAF ou Redis et configurer correctement les proxies/IP clientes.
5. **GPS :** les coordonnées restent déclaratives ; mettre en place un canal signé entre boîtiers et serveur avant d'afficher une position comme fiable.
6. **Données personnelles :** vérifier le strict nécessaire des objets JPA renvoyés directement, limiter la conservation des CNI, publier politique de confidentialité et contacts officiels.
7. **Déploiement :** HTTPS, sauvegardes testées, stockage des secrets, observabilité, gestion d'incidents et journaux d'audit.
8. **Design :** test manuel des parcours complets, affichages mobile/tablette, performances du bus 3D sur matériel réel, alternatives `prefers-reduced-motion` et navigation clavier.
9. **Qualité :** terminer l'installation des dépendances, valider le lint et les builds sur les machines et CI.

## 4. Ordre de validation recommandé

1. Faire tourner les jobs GitHub Actions `frontend` et `backend` et corriger les erreurs de compilation/lint.
2. Démarrer une base **neuve et isolée**, importer le script initial uniquement sur cette base, vérifier les droits et appliquer les migrations si nécessaire.
3. Exécuter les tests d'intégration JPA et un scénario de concurrence sur la vente du dernier siège.
4. Tester l'ensemble des rôles et la nouvelle affectation des chauffeurs et des balises.
5. Faire les transactions de test Monetbil avec le prestataire et vérifier les IPN et remboursements.
6. Auditer visuellement le site et son animation en navigateur réel, puis seulement envisager la publication.

**Aucun audit honnête ne peut garantir « zéro bug » ou « perfection absolue ».** Cette archive représente des corrections contrôlées et documentées, non une certification de mise en production.
