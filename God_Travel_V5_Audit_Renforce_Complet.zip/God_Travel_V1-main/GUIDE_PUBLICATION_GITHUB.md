# God Travel V4 — Installer sur Windows et publier les sources sur GitHub

Dépôt visé : https://github.com/kiyotaka-sudo/God_Travel_V1

## 1. Décompresser l’archive

Extraire `God_Travel_V4_Premium_Securise.zip`. Ouvrir le dossier qui contient **`god-travel-frontend`**, **`god-travel-backend`**, **`database`** et **`README.md`** dans Visual Studio Code. **Ne pas exécuter `npm` au niveau du dossier racine.**

## 2. Tester l’interface sur Windows

Dans le terminal VS Code, depuis la racine du projet :

```powershell
cd .\god-travel-frontend
npm.cmd ci
npm.cmd test
npm.cmd run lint
npm.cmd run build
npm.cmd run dev
```

Ouvrir `http://localhost:5173`. Si PowerShell bloque `npm.ps1`, utiliser **`npm.cmd`** comme dans ces commandes. Le frontend peut s’afficher sans backend, mais aucune réservation ne sera finalisée.

## 3. Démarrer le backend

Installer Java 17+ et Maven puis MySQL/MariaDB. Pour une démonstration **uniquement sur une base neuve et vide**, importer `god_travel_complet_master.sql` dans phpMyAdmin. Pour une base vierge sans données fictives, importer `database/schema_production.sql` puis configurer les référentiels entreprise/agence/profil/employé avec les vraies informations de l’exploitant. **Ces deux SQL recréent les tables** : ils détruisent les données de tables portant les mêmes noms ; ne jamais les lancer sur une base de production existante.

Une installation V1/V2 déjà remplie doit être sauvegardée et migrée avec `database/migrations/V3__booking_index_and_availability.sql` **une seule fois** après vérification de l’index présent. Ne pas réimporter le master.

Copier `god-travel-backend/src/main/resources/application.example.properties` sous le nom `application.properties` (ignoré par Git). Vérifier le port MySQL (3307 par défaut dans cet exemple, souvent 3306 dans XAMPP).

Dans un terminal PowerShell situé dans `god-travel-backend` :

```powershell
$env:APP_JWT_SECRET = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$env:APP_TICKET_HMAC_SECRET = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$env:APP_BOOTSTRAP_ADMIN_PASSWORD = Read-Host 'Mot de passe administrateur (au moins 12 caractères)'
mvn test
mvn spring-boot:run
```

L'amorçage admin nécessite `EMP-001` et `ROLE_ADMIN` dans la base. Le master de démonstration inclut ces référentiels, pas de compte avec mot de passe partagé. Supprimer `APP_BOOTSTRAP_ADMIN_PASSWORD` de l'environnement après le premier démarrage réussi ; les secrets JWT/HMAC doivent être **persistés de manière sûre et stable** entre les redémarrages afin de ne pas invalider les sessions et signatures.

## 4. Publier les fichiers dans le dépôt existant

**GitHub n’extrait pas un ZIP à l’intérieur du dépôt.** Décompresser d’abord. Le plus sûr est de cloner le dépôt existant et d’y copier le contenu extrait, sans copier `node_modules`, `dist`, `target`, fichiers `.env`, `application.properties` ni dossier `.git` provenant d’une autre copie.

```powershell
git clone https://github.com/kiyotaka-sudo/God_Travel_V1.git
cd .\God_Travel_V1
# Copier ici le contenu du dossier God_Travel_V1-main extrait
# Vérifier les changements avant validation :
git status
git add -A
git commit -m "God Travel V4 - recherche, animation et securite"
git push origin main
```

Si la branche par défaut est différente de `main`, remplacer ce nom par le nom réel. Git peut demander une authentification et refuser un push lorsque le dépôt distant a reçu de nouveaux commits : dans ce cas, synchroniser avant de recommencer, **ne pas forcer le push**.

## 5. Publication auprès des clients

Le dépôt héberge le **code**, pas automatiquement la base et le backend. Pour un lancement réel : domaine + certificat HTTPS, hébergement Java, base MySQL sécurisée, secrets stables, `APP_CORS_ALLOWED_ORIGINS`, `MONETBIL_PUBLIC_BASE_URL`, `GOD_TRAVEL_FRONTEND_URL`, contrôle du paiement et tests CI. Voir `RAPPORT_REFONTE_GOD_TRAVEL.md` pour les prérequis encore bloquants.

## 6. Changements d’API V4 (important pour les anciens clients)

Les vérifications publiques de billet et de paiement demandent désormais une requête **POST** JSON, pour éviter de placer les téléphones dans une URL :

- `POST /api/billets/consulter` : `{"codeBillet":"GT-...","telephone":"699000000"}`
- `POST /api/paiements/monetbil/statut` : `{"reference":"GT-...","telephone":"699000000"}`

Les anciennes requêtes GET correspondantes ne sont plus proposées. Le frontend V4 est déjà adapté. Le suivi de colis reste en `POST /api/colis/public/suivi`.

## 7. Sécurité et exploitation

Les limites de requêtes `APP_AUTH_MAX_PER_MINUTE` (20 par défaut) et `APP_LOOKUP_MAX_PER_MINUTE` (90 par défaut) sont implémentées **en mémoire par adresse IP et par instance**. Elles sont une protection de première ligne, pas un substitut à une limitation distribuée en production. Configurer le reverse proxy pour qu’il transmette une adresse IP client fiable sans accepter d’en-têtes forgés.

Tester la désactivation d’un compte avec un JWT encore valide, la reconnexion, les recherches publiques, les réponses `429` et les écrans mobiles. Ne jamais prendre un statut de retour navigateur pour une preuve de paiement : seule une notification Monetbil authentifiée permet la validation.

Avant de publier : lancer les tâches GitHub Actions, **vérifier les résultats**, tester les transactions contre une vraie base de recette, les paiements avec un environnement approuvé du fournisseur, les sauvegardes et restaurations, ainsi que les conditions légales et contacts d’assistance. Un dépôt GitHub n’héberge pas à lui seul l’API et MySQL.
