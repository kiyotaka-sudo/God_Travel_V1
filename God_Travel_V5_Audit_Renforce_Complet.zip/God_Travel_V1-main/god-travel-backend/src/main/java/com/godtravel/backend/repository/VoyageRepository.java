package com.godtravel.backend.repository;

import com.godtravel.backend.model.entity.Voyage;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface VoyageRepository extends JpaRepository<Voyage, String> {
    Optional<Voyage> findByCodeVoyage(String codeVoyage);

    // Verrou transactionnel : sérialise le contrôle de siège et la création du billet
    // pour un même voyage, y compris sous charge concurrente multi-instances.
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT v FROM Voyage v WHERE v.idVoyage = :idVoyage")
    Optional<Voyage> findByIdForBooking(@Param("idVoyage") String idVoyage);
    List<Voyage> findByStatutVoyage(String statutVoyage);
    List<Voyage> findByAgence_IdAgence(String idAgence);

    /** Restrict driver GPS submissions to an assigned driving role on that specific departure. */
    @Query(value = "SELECT COUNT(*) FROM AFFECTER_EQUIPAGE ae " +
            "JOIN ROLE_VOYAGE rv ON rv.ID_ROLE_VOYAGE = ae.ID_ROLE_VOYAGE " +
            "WHERE ae.ID_VOYAGE = :idVoyage AND ae.ID_EMPLOYE = :idEmploye " +
            "AND rv.CODE_ROLE IN ('CHAUFFEUR_PRINCIPAL', 'CHAUFFEUR_RELAIS')", nativeQuery = true)
    long countChauffeurAffecte(@Param("idVoyage") String idVoyage, @Param("idEmploye") String idEmploye);

    /** Do not accept GPS data for an unrelated device/bus. */
    @Query(value = "SELECT COUNT(*) FROM BALISE_GPS bg WHERE bg.ID_BALISE = :idBalise " +
            "AND bg.ID_BUS = :idBus", nativeQuery = true)
    long countBalisePourBus(@Param("idBalise") String idBalise, @Param("idBus") String idBus);


    @Query("SELECT v FROM Voyage v WHERE v.ligne.idLigne = :idLigne AND v.dateHeureDepartPrevue >= :dateDebut AND v.statutVoyage IN ('PROGRAMME', 'OUVERT', 'CONFIRME') ORDER BY v.dateHeureDepartPrevue ASC")
    List<Voyage> findVoyagesDisponibles(@Param("idLigne") String idLigne, @Param("dateDebut") LocalDateTime dateDebut);
}

