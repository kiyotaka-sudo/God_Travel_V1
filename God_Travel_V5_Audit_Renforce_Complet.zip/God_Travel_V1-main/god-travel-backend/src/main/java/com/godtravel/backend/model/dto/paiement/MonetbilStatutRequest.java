package com.godtravel.backend.model.dto.paiement;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Vérification de paiement : informations sensibles envoyées dans le corps de la requête. */
public record MonetbilStatutRequest(
        @NotBlank @Size(max = 60) String reference,
        @NotBlank @Size(max = 25) String telephone
) {}
