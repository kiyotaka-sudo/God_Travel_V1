package com.godtravel.backend.model.dto.billetterie;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Requête POST : le téléphone ne figure pas dans les URL, historiques ou proxies HTTP. */
public record BilletConsultationRequest(
        @NotBlank @Size(max = 60) String codeBillet,
        @NotBlank @Size(max = 25) String telephone
) {}
