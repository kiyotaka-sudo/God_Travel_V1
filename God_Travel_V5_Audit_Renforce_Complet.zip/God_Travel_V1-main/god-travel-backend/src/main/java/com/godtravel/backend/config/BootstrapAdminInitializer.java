package com.godtravel.backend.config;

import com.godtravel.backend.model.entity.Utilisateur;
import com.godtravel.backend.repository.EmployeRepository;
import com.godtravel.backend.repository.ProfilRepository;
import com.godtravel.backend.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/** Premier accès administrateur, indépendant de l'activation des données de démonstration. */
@Component
@Order(2)
@RequiredArgsConstructor
@Slf4j
public class BootstrapAdminInitializer implements CommandLineRunner {

    private final UtilisateurRepository utilisateurRepository;
    private final EmployeRepository employeRepository;
    private final ProfilRepository profilRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.bootstrap-admin-password:}") private String bootstrapAdminPassword;
    @Value("${app.bootstrap-admin-login:admin@godtravel.cm}") private String bootstrapAdminLogin;

    @Override
    @Transactional
    public void run(String... args) {
        if (bootstrapAdminPassword == null || bootstrapAdminPassword.isBlank()) {
            log.warn("Aucun mot de passe de bootstrap défini : aucune création automatique de compte administrateur.");
            return;
        }
        if (bootstrapAdminPassword.length() < 12) {
            log.warn("Mot de passe administrateur refusé : au moins 12 caractères sont requis.");
            return;
        }
        String login = bootstrapAdminLogin.trim().toLowerCase(java.util.Locale.ROOT);
        if (utilisateurRepository.existsByLogin(login)) return;

        var profil = profilRepository.findByCodeProfil("ROLE_ADMIN")
                .or(() -> profilRepository.findByCodeProfil("ADMIN"));
        var employe = employeRepository.findById("EMP-001");
        if (profil.isEmpty() || employe.isEmpty()) {
            log.warn("Bootstrap impossible : initialisez d'abord le profil ADMIN et l'employé EMP-001. Aucun compte fictif n'est créé.");
            return;
        }
        utilisateurRepository.save(Utilisateur.builder()
                .idUtilisateur("USR-" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 15).toUpperCase())
                .employe(employe.get()).profil(profil.get())
                .login(login).motDePasseHash(passwordEncoder.encode(bootstrapAdminPassword))
                .estActif(true).build());
        log.info("Compte administrateur initial créé : changez ou retirez APP_BOOTSTRAP_ADMIN_PASSWORD après le premier démarrage.");
    }
}
