package com.godtravel.backend.service;

import com.godtravel.backend.exception.BusinessException;
import com.godtravel.backend.exception.ResourceNotFoundException;
import com.godtravel.backend.model.dto.colis.ColisCreationRequest;
import com.godtravel.backend.model.dto.colis.ColisTrackingView;
import com.godtravel.backend.model.dto.colis.AgenceOptionView;
import com.godtravel.backend.model.entity.*;
import com.godtravel.backend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ColisService {

    private final ColisRepository colisRepository;
    private final ClientRepository clientRepository;
    private final AgenceRepository agenceRepository;
    private final VoyageRepository voyageRepository;
    private final UtilisateurRepository utilisateurRepository;

    @Transactional(readOnly = true)
    public List<AgenceOptionView> listerOptionsAgences() {
        return agenceRepository.findAll().stream()
                .map(agence -> new AgenceOptionView(agence.getIdAgence(), agence.getNomAgence(),
                        agence.getVille() == null ? "" : agence.getVille().getNomVille()))
                .sorted(java.util.Comparator.comparing(AgenceOptionView::nomAgence))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<Colis> listerColis(String statut) {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) throw new BusinessException("Authentification requise.");
        boolean admin = auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        List<Colis> visibles;
        if (admin) {
            visibles = colisRepository.findAll();
        } else {
            Utilisateur utilisateur = utilisateurRepository.findByLogin(auth.getName())
                    .orElseThrow(() -> new BusinessException("Agent connecté introuvable."));
            if (utilisateur.getEmploye() == null || utilisateur.getEmploye().getAgence() == null)
                throw new BusinessException("Votre compte doit être rattaché à une agence.");
            String agenceId = utilisateur.getEmploye().getAgence().getIdAgence();
            var distincts = new LinkedHashMap<String, Colis>();
            colisRepository.findByAgenceDepot_IdAgence(agenceId).forEach(c -> distincts.put(c.getIdColis(), c));
            colisRepository.findByAgenceRetrait_IdAgence(agenceId).forEach(c -> distincts.put(c.getIdColis(), c));
            visibles = List.copyOf(distincts.values());
        }
        return statut == null || statut.isBlank() ? visibles : visibles.stream()
                .filter(c -> statut.equals(c.getStatutColis())).toList();
    }

    public Colis getColisParCodeSuivi(String codeSuivi) {
        return colisRepository.findByCodeSuivi(codeSuivi)
                .orElseThrow(() -> new ResourceNotFoundException("Colis", "codeSuivi", codeSuivi));
    }

    @Transactional(readOnly = true)
    public Colis suivreColisInterne(String codeSuivi) {
        Colis colis = getColisParCodeSuivi(codeSuivi);
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) throw new BusinessException("Authentification requise.");
        boolean admin = auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        if (!admin) {
            Utilisateur utilisateur = utilisateurRepository.findByLogin(auth.getName())
                    .orElseThrow(() -> new BusinessException("Agent connecté introuvable."));
            String agence = utilisateur.getEmploye() == null || utilisateur.getEmploye().getAgence() == null
                    ? "" : utilisateur.getEmploye().getAgence().getIdAgence();
            if (!agence.equals(colis.getAgenceDepot().getIdAgence())
                    && !agence.equals(colis.getAgenceRetrait().getIdAgence()))
                throw new ResourceNotFoundException("Colis", "codeSuivi", codeSuivi);
        }
        return colis;
    }

    /** Vue publique minimisée : le code de suivi seul ne suffit pas pour accéder aux détails. */
    @Transactional(readOnly = true)
    public ColisTrackingView suivreColisPublic(String codeSuivi, String telephone) {
        if (codeSuivi == null || codeSuivi.isBlank() || telephone == null || telephone.isBlank()) {
            throw new ResourceNotFoundException("Colis", "référence", "non trouvée");
        }
        Colis colis = getColisParCodeSuivi(codeSuivi.trim());
        String fourni = normaliserTelephone(telephone);
        if (!fourni.matches("6\\d{8}") ||
                (!fourni.equals(normaliserTelephone(colis.getTelephoneDestinataire()))
                        && !fourni.equals(normaliserTelephone(colis.getClientExpediteur().getTelephone())))) {
            throw new ResourceNotFoundException("Colis", "référence", "non trouvée");
        }
        return new ColisTrackingView(colis.getCodeSuivi(), colis.getStatutColis(),
                colis.getAgenceDepot().getVille().getNomVille(),
                colis.getAgenceRetrait().getVille().getNomVille(),
                colis.getDateEnregistrement(), colis.getDateRemise());
    }

    private String normaliserTelephone(String telephone) {
        String digits = telephone == null ? "" : telephone.replaceAll("[^0-9]", "");
        return digits.startsWith("237") && digits.length() == 12 ? digits.substring(3) : digits;
    }

    @Transactional
    public Colis enregistrerColis(ColisCreationRequest req) {
        Agence agenceRetrait = agenceRepository.findById(req.getIdAgenceRetrait())
                .orElseThrow(() -> new ResourceNotFoundException("Agence Retrait", "id", req.getIdAgenceRetrait()));

        String login = SecurityContextHolder.getContext().getAuthentication().getName();
        Utilisateur agent = utilisateurRepository.findByLogin(login)
                .orElseThrow(() -> new BusinessException("Agent connecté non trouvé."));

        Employe employe = agent.getEmploye();
        Agence agenceDepot = employe != null ? employe.getAgence() : null;
        if (agenceDepot == null) {
            throw new BusinessException("Votre compte doit être rattaché à une agence pour enregistrer un colis.");
        }

        Client clientExpediteur = clientRepository.findByTelephone(req.getTelephoneExpediteur())
                .orElseGet(() -> {
                    String idCli = "CLI-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
                    Client c = Client.builder()
                            .idClient(idCli)
                            .nom(req.getNomExpediteur())
                            .telephone(req.getTelephoneExpediteur())
                            .build();
                    return clientRepository.save(c);
                });

        Voyage voyage = null;
        if (req.getIdVoyage() != null) {
            voyage = voyageRepository.findById(req.getIdVoyage()).orElse(null);
        }

        String idColis = "CLS-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        String codeSuivi = "TRK-" + DateTimeFormatter.ofPattern("ddMM").format(LocalDateTime.now()) + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        Colis colis = Colis.builder()
                .idColis(idColis)
                .clientExpediteur(clientExpediteur)
                .agenceDepot(agenceDepot)
                .agenceRetrait(agenceRetrait)
                .voyage(voyage)
                .employe(employe)
                .codeSuivi(codeSuivi)
                .nomDestinataire(req.getNomDestinataire())
                .prenomDestinataire(req.getPrenomDestinataire())
                .telephoneDestinataire(req.getTelephoneDestinataire())
                .cniDestinataire(req.getCniDestinataire())
                .descriptionContenu(req.getDescriptionContenu())
                .poidsKg(req.getPoidsKg())
                .valeurDeclareeXaf(req.getValeurDeclaree() != null ? req.getValeurDeclaree() : java.math.BigDecimal.ZERO)
                .fraisExpeditionXaf(req.getFraisExpedition())
                .dateEnregistrement(LocalDateTime.now())
                .statutColis("ENREGISTRE")
                .build();

        return colisRepository.save(colis);
    }

    /** Seuls les employés de l'agence concernée peuvent faire avancer le colis. */
    private void verifierAgence(Agence agenceAutorisee) {
        var authentification = SecurityContextHolder.getContext().getAuthentication();
        if (authentification == null) throw new BusinessException("Authentification requise.");
        boolean admin = authentification.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        if (admin) return;
        Utilisateur utilisateur = utilisateurRepository.findByLogin(authentification.getName())
                .orElseThrow(() -> new BusinessException("Agent connecté introuvable."));
        if (utilisateur.getEmploye() == null || utilisateur.getEmploye().getAgence() == null
                || !utilisateur.getEmploye().getAgence().getIdAgence().equals(agenceAutorisee.getIdAgence())) {
            throw new BusinessException("Ce colis appartient à une autre agence.");
        }
    }

    @Transactional
    public Colis enregistrerDepart(String idColis) {
        Colis colis = colisRepository.findById(idColis)
                .orElseThrow(() -> new ResourceNotFoundException("Colis", "id", idColis));
        verifierAgence(colis.getAgenceDepot());
        if (!"ENREGISTRE".equals(colis.getStatutColis()))
            throw new BusinessException("Seul un colis enregistré peut partir de l'agence.");
        colis.setStatutColis("EN_TRANSIT");
        return colisRepository.save(colis);
    }

    @Transactional
    public Colis enregistrerArrivee(String idColis) {
        Colis colis = colisRepository.findById(idColis)
                .orElseThrow(() -> new ResourceNotFoundException("Colis", "id", idColis));
        verifierAgence(colis.getAgenceRetrait());
        if (!"EN_TRANSIT".equals(colis.getStatutColis()))
            throw new BusinessException("Seul un colis en transit peut être marqué comme arrivé.");
        colis.setStatutColis("ARRIVE_AGENCE");
        return colisRepository.save(colis);
    }

    @Transactional
    public Colis remettreColis(String idColis, String cniDestinataire) {
        Colis colis = colisRepository.findById(idColis)
                .orElseThrow(() -> new ResourceNotFoundException("Colis", "id", idColis));
        verifierAgence(colis.getAgenceRetrait());
        if (!"ARRIVE_AGENCE".equals(colis.getStatutColis()))
            throw new BusinessException("La remise n'est possible qu'après l'enregistrement de l'arrivée en agence.");
        if (cniDestinataire == null || cniDestinataire.isBlank())
            throw new BusinessException("La pièce d'identité vérifiée est obligatoire.");
        if (colis.getCniDestinataire() != null && !colis.getCniDestinataire().isBlank()
                && !colis.getCniDestinataire().trim().equalsIgnoreCase(cniDestinataire.trim()))
            throw new BusinessException("Le numéro présenté ne correspond pas à la pièce enregistrée. Faites vérifier le dossier par le responsable.");
        colis.setCniDestinataire(cniDestinataire.trim());
        colis.setDateRemise(LocalDateTime.now());
        colis.setStatutColis("LIVRE");
        return colisRepository.save(colis);
    }
}

