package com.godtravel.backend.controller;

import com.godtravel.backend.model.dto.ApiResponse;
import com.godtravel.backend.exception.BusinessException;
import com.godtravel.backend.model.dto.colis.ColisCreationRequest;
import com.godtravel.backend.model.dto.colis.ColisTrackingView;
import com.godtravel.backend.model.dto.colis.ColisSuiviRequest;
import com.godtravel.backend.model.dto.colis.AgenceOptionView;
import com.godtravel.backend.model.entity.Colis;
import com.godtravel.backend.service.ColisService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/colis")
@RequiredArgsConstructor
public class ColisController {

    private final ColisService colisService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<List<Colis>>> listerColis(@RequestParam(value = "statut", required = false) String statut) {
        List<Colis> list = colisService.listerColis(statut);
        return ResponseEntity.ok(ApiResponse.ok(list));
    }

    @PostMapping("/public/suivi")
    public ResponseEntity<ApiResponse<ColisTrackingView>> suivreColisPublic(
            @Valid @RequestBody ColisSuiviRequest demande
    ) {
        return ResponseEntity.ok().header(HttpHeaders.CACHE_CONTROL, "no-store")
                .body(ApiResponse.ok(colisService.suivreColisPublic(demande.codeSuivi(), demande.telephone())));
    }

    @GetMapping("/agences")
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<List<AgenceOptionView>>> optionsAgences() {
        return ResponseEntity.ok(ApiResponse.ok(colisService.listerOptionsAgences()));
    }

    @GetMapping("/suivi/{codeSuivi}")
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<Colis>> suivreColis(@PathVariable("codeSuivi") String codeSuivi) {
        Colis colis = colisService.suivreColisInterne(codeSuivi);
        return ResponseEntity.ok(ApiResponse.ok(colis));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<Colis>> enregistrerColis(@Valid @RequestBody ColisCreationRequest request) {
        Colis colis = colisService.enregistrerColis(request);
        return ResponseEntity.ok(ApiResponse.ok("Colis enregistré avec succès", colis));
    }

    @PutMapping("/{id}/depart")
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<Colis>> departColis(@PathVariable("id") String idColis) {
        return ResponseEntity.ok(ApiResponse.ok("Colis parti de l'agence", colisService.enregistrerDepart(idColis)));
    }

    @PutMapping("/{id}/arrivee")
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<Colis>> arriveeColis(@PathVariable("id") String idColis) {
        return ResponseEntity.ok(ApiResponse.ok("Colis arrivé à l'agence de retrait", colisService.enregistrerArrivee(idColis)));
    }

    @PutMapping("/{id}/remise")
    @PreAuthorize("hasAnyRole('ADMIN', 'CHEF_AGENCE', 'GUICHETIER')")
    public ResponseEntity<ApiResponse<Colis>> remettreColis(
            @PathVariable("id") String idColis,
            @RequestBody Map<String, String> body
    ) {
        String cni = body == null ? null : body.get("cniDestinataire");
        if (cni == null || cni.isBlank()) {
            throw new BusinessException("La pièce d'identité vérifiée du destinataire est obligatoire pour la remise.");
        }
        cni = cni.trim();
        Colis colis = colisService.remettreColis(idColis, cni);
        return ResponseEntity.ok(ApiResponse.ok("Colis retiré par le destinataire", colis));
    }
}

