package com.godtravel.backend.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Limitation locale sans confiance dans des en-têtes IP fournis par le navigateur. */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
@RequiredArgsConstructor
public class PublicRateLimitFilter extends OncePerRequestFilter {
    private final InMemoryRateLimiter limiter;

    @Value("${app.security.auth-max-per-minute:20}")
    private int authMaxPerMinute;
    @Value("${app.security.lookup-max-per-minute:90}")
    private int lookupMaxPerMinute;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        if (!"POST".equals(request.getMethod())) {
            filterChain.doFilter(request, response);
            return;
        }
        String path = request.getServletPath();
        boolean isAuth = path.equals("/auth/login") || path.equals("/auth/client/connexion")
                || path.equals("/auth/client/inscription");
        boolean isLookup = path.equals("/billets/consulter") || path.equals("/colis/public/suivi")
                || path.equals("/paiements/monetbil/statut");
        if (!isAuth && !isLookup) {
            filterChain.doFilter(request, response);
            return;
        }

        String scope = isAuth ? "auth" : "lookup";
        int limit = isAuth ? Math.max(1, authMaxPerMinute) : Math.max(1, lookupMaxPerMinute);
        String address = request.getRemoteAddr();
        if (!limiter.allow(scope + ":" + address, limit, System.currentTimeMillis())) {
            response.setStatus(429);
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.setHeader("Retry-After", "60");
            response.setHeader("Cache-Control", "no-store");
            response.getWriter().write("{\"success\":false,\"error\":\"RATE_LIMITED\",\"message\":\"Trop de tentatives. Réessayez dans une minute.\"}");
            return;
        }
        filterChain.doFilter(request, response);
    }
}
