package com.godtravel.backend.model.dto.colis;

/** Données minimales nécessaires au formulaire de dépôt de colis. */
public record AgenceOptionView(String idAgence, String nomAgence, String ville) {}
