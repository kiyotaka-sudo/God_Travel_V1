package com.godtravel.backend.repository;

import com.godtravel.backend.model.entity.Paiement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaiementRepository extends JpaRepository<Paiement, String> {
    List<Paiement> findByClotureCaisse_IdCloture(String idCloture);
    Optional<Paiement> findByReferenceTransaction(String referenceTransaction);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Paiement p WHERE p.referenceTransaction = :reference")
    Optional<Paiement> findByReferenceTransactionForUpdate(@Param("reference") String reference);

    boolean existsByBillet_IdBilletAndStatutPaiement(String idBillet, String statutPaiement);
}

