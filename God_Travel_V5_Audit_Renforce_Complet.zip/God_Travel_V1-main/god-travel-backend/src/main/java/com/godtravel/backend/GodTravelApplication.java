package com.godtravel.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GodTravelApplication {

    public static void main(String[] args) {
        // Les dates métier historiques utilisent LocalDateTime (sans zone) ;
        // garantir leur interprétation en heure du Cameroun sur tous les serveurs.
        java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("Africa/Douala"));
        SpringApplication.run(GodTravelApplication.class, args);
    }
}

