package com.godtravel.backend.security;

import org.springframework.stereotype.Component;
import java.util.concurrent.ConcurrentHashMap;

/** Protection locale best-effort ; production multi-instance : utiliser Redis/API gateway. */
@Component
public class InMemoryRateLimiter {
    private static final long WINDOW_MILLIS = 60_000L;
    private static final int MAX_WINDOWS = 10_000;
    private final ConcurrentHashMap<String, Window> windows = new ConcurrentHashMap<>();

    public boolean allow(String key, int maxRequests, long nowMillis) {
        // A distributed botnet can otherwise create unbounded entries in a single minute.
        // Fail closed for new IPs at capacity; retain existing buckets until expiry.
        if (!windows.containsKey(key) && windows.size() >= MAX_WINDOWS) {
            windows.entrySet().removeIf(entry ->
                    nowMillis < entry.getValue().startedAt ||
                    nowMillis - entry.getValue().startedAt >= WINDOW_MILLIS);
            if (windows.size() >= MAX_WINDOWS) return false;
        }
        Window window = windows.compute(key, (ignored, previous) -> {
            if (previous == null || nowMillis - previous.startedAt >= WINDOW_MILLIS || nowMillis < previous.startedAt)
                return new Window(nowMillis, 1);
            return new Window(previous.startedAt, previous.count + 1);
        });
        return window.count <= maxRequests;
    }

    private record Window(long startedAt, int count) {}
}
