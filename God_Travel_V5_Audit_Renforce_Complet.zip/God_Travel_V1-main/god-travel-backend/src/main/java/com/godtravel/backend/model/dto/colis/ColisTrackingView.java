package com.godtravel.backend.model.dto.colis;

import java.time.LocalDateTime;

/** Uniquement les champs destinés au suivi public, sans informations personnelles. */
public record ColisTrackingView(
        String codeSuivi,
        String statut,
        String villeDepart,
        String villeArrivee,
        LocalDateTime dateEnregistrement,
        LocalDateTime dateRemise
) {}
