package com.godtravel.backend.model.dto.gps;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PointageGpsDto {

    @NotBlank(message = "L'identifiant balise est obligatoire")
    @Size(max = 20)
    private String idBalise;

    @NotBlank(message = "Le voyage est obligatoire")
    @Size(max = 20)
    private String idVoyage;

    @NotNull(message = "La latitude est obligatoire")
    @DecimalMin("-90.0")
    @DecimalMax("90.0")
    private BigDecimal latitude;

    @NotNull(message = "La longitude est obligatoire")
    @DecimalMin("-180.0")
    @DecimalMax("180.0")
    private BigDecimal longitude;

    @Min(0)
    @Max(250)
    private Integer vitesseKmh;
}

