package com.godtravel.backend.service;

import com.godtravel.backend.exception.ResourceNotFoundException;
import com.godtravel.backend.exception.BusinessException;
import com.godtravel.backend.model.entity.Utilisateur;
import com.godtravel.backend.repository.UtilisateurRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import com.godtravel.backend.model.dto.gps.PointageGpsDto;
import com.godtravel.backend.model.entity.AlerteGps;
import com.godtravel.backend.model.entity.PositionGps;
import com.godtravel.backend.model.entity.Voyage;
import com.godtravel.backend.repository.AlerteGpsRepository;
import com.godtravel.backend.repository.PositionGpsRepository;
import com.godtravel.backend.repository.VoyageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GpsService {

    private final PositionGpsRepository positionGpsRepository;
    private final AlerteGpsRepository alerteGpsRepository;
    private final VoyageRepository voyageRepository;
    private final UtilisateurRepository utilisateurRepository;

    @Transactional(readOnly = true)
    public List<PositionGps> getLatestPositions() {
        String agence = agenceDeLecture();
        return positionGpsRepository.findLatestPositions().stream()
                .filter(pos -> agence == null || agence.equals(pos.getVoyage().getAgence().getIdAgence()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AlerteGps> getAlertesActives() {
        String agence = agenceDeLecture();
        return alerteGpsRepository.findByEstAcquitteeFalseOrderByDateHeureAlerteDesc().stream()
                .filter(alerte -> agence == null || agence.equals(alerte.getVoyage().getAgence().getIdAgence()))
                .toList();
    }

    /** null means an administrator can inspect all agencies. */
    private String agenceDeLecture() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated())
            throw new BusinessException("Authentification GPS requise.");
        if (auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority())))
            return null;
        if (auth.getAuthorities().stream().noneMatch(a -> "ROLE_CHEF_AGENCE".equals(a.getAuthority())))
            throw new BusinessException("Lecture GPS réservée à la direction de l'agence.");
        Utilisateur user = utilisateurRepository.findByLogin(auth.getName())
                .orElseThrow(() -> new BusinessException("Compte agent introuvable."));
        if (user.getEmploye() == null || user.getEmploye().getAgence() == null
                || !"ACTIF".equals(user.getEmploye().getStatutEmploye()))
            throw new BusinessException("Employé non actif ou sans agence.");
        return user.getEmploye().getAgence().getIdAgence();
    }

    @Transactional
    public PositionGps enregistrerPosition(PointageGpsDto dto) {
        Voyage voyage = voyageRepository.findById(dto.getIdVoyage())
                .orElseThrow(() -> new ResourceNotFoundException("Voyage", "id", dto.getIdVoyage()));

        // A valid JWT is insufficient: check employee, agency, trip assignment and device.
        verifierHabilitation(voyage);
        if (voyage.getBus() == null || voyageRepository.countBalisePourBus(dto.getIdBalise(), voyage.getBus().getIdBus()) != 1) {
            throw new BusinessException("La balise GPS ne correspond pas au bus de ce voyage.");
        }
        if ("ANNULE".equals(voyage.getStatutVoyage()) || "TERMINE".equals(voyage.getStatutVoyage())) {
            throw new BusinessException("Les pointages GPS sont clos pour ce voyage.");
        }

        String idPos = "POS-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        PositionGps pos = PositionGps.builder()
                .idPosition(idPos)
                .idBalise(dto.getIdBalise())
                .voyage(voyage)
                .latitude(dto.getLatitude())
                .longitude(dto.getLongitude())
                .vitesseKmh(dto.getVitesseKmh())
                .dateHeureReleve(LocalDateTime.now())
                .build();

        PositionGps saved = positionGpsRepository.save(pos);

        // Détection automatique de survitesse (> 100 km/h)
        if (dto.getVitesseKmh() != null && dto.getVitesseKmh() > 100) {
            String idAlerte = "ALT-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
            AlerteGps alerte = AlerteGps.builder()
                    .idAlerteGps(idAlerte)
                    .voyage(voyage)
                    .typeAlerte("EXCES_VITESSE")
                    .dateHeureAlerte(LocalDateTime.now())
                    .messageAlerte("Excès de vitesse détecté : " + dto.getVitesseKmh() + " km/h sur le voyage " + voyage.getCodeVoyage())
                    .estAcquittee(false)
                    .build();
            alerteGpsRepository.save(alerte);
        }

        return saved;
    }

    private void verifierHabilitation(Voyage voyage) {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName().startsWith("client:")) {
            throw new BusinessException("Accès GPS réservé à l'équipe authentifiée.");
        }
        boolean admin = auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        boolean chef = auth.getAuthorities().stream().anyMatch(a -> "ROLE_CHEF_AGENCE".equals(a.getAuthority()));
        boolean chauffeur = auth.getAuthorities().stream().anyMatch(a -> "ROLE_CHAUFFEUR".equals(a.getAuthority()));
        if (!admin && !chef && !chauffeur) throw new BusinessException("Droits GPS insuffisants.");
        if (admin) return;

        Utilisateur user = utilisateurRepository.findByLogin(auth.getName())
                .orElseThrow(() -> new BusinessException("Compte agent introuvable."));
        var employe = user.getEmploye();
        if (employe == null || employe.getAgence() == null || !"ACTIF".equals(employe.getStatutEmploye())) {
            throw new BusinessException("Employé non actif ou sans agence.");
        }
        if (!employe.getAgence().getIdAgence().equals(voyage.getAgence().getIdAgence())) {
            throw new BusinessException("Ce voyage ne dépend pas de votre agence.");
        }
        if (chauffeur && !chef && voyageRepository.countChauffeurAffecte(
                voyage.getIdVoyage(), employe.getIdEmploye()) != 1) {
            throw new BusinessException("Chauffeur non affecté à ce voyage.");
        }
    }

    @Transactional
    public AlerteGps acquitterAlerte(String idAlerte) {
        AlerteGps alerte = alerteGpsRepository.findById(idAlerte)
                .orElseThrow(() -> new ResourceNotFoundException("AlerteGps", "id", idAlerte));
        String agence = agenceDeLecture();
        if (agence != null && !agence.equals(alerte.getVoyage().getAgence().getIdAgence())) {
            throw new ResourceNotFoundException("AlerteGps", "id", idAlerte);
        }
        alerte.setEstAcquittee(true);
        return alerteGpsRepository.save(alerte);
    }
}

