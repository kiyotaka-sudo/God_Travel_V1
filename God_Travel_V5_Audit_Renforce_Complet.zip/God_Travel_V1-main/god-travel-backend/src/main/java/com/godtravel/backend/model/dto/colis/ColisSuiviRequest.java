package com.godtravel.backend.model.dto.colis;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Le numéro ne figure pas dans l'URL et n'est pas exposé aux journaux de navigation. */
public record ColisSuiviRequest(
        @NotBlank @Size(max = 30) String codeSuivi,
        @NotBlank @Size(max = 25) String telephone
) {}
