package com.godtravel.backend.service;

import com.godtravel.backend.exception.BusinessException;
import com.godtravel.backend.model.dto.paiement.MonetbilInitRequest;
import com.godtravel.backend.model.entity.Agence;
import com.godtravel.backend.model.entity.Colis;
import com.godtravel.backend.model.entity.Employe;
import com.godtravel.backend.model.entity.Utilisateur;
import com.godtravel.backend.repository.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MonetbilServiceTest {
    @Mock private PaiementRepository paiements;
    @Mock private VoyageRepository voyages;
    @Mock private ModePaiementRepository modes;
    @Mock private BilletRepository billets;
    @Mock private ColisRepository colisRepo;
    @Mock private UtilisateurRepository utilisateurs;
    @InjectMocks private MonetbilService service;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(service, "serviceKey", "key-for-test");
        ReflectionTestUtils.setField(service, "serviceSecret", "secret-for-test");
    }

    @AfterEach
    void teardown() { SecurityContextHolder.clearContext(); }

    private MonetbilInitRequest demandeColis() {
        return MonetbilInitRequest.builder().typeItem("COLIS").idItem("CLS-01")
                .montant(BigDecimal.valueOf(1200)).telephone("699000000").build();
    }

    @Test
    void unVoyageurNePeutPasPayerUnColisArbitraire() {
        Colis colis = mock(Colis.class);
        Agence depot = mock(Agence.class);
        when(colisRepo.findById("CLS-01")).thenReturn(Optional.of(colis));
        when(colis.getAgenceDepot()).thenReturn(depot);
        when(depot.getIdAgence()).thenReturn("AGC-YDE");
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                "client:client@example.com", null, List.of(new SimpleGrantedAuthority("ROLE_CLIENT"))));

        assertThrows(BusinessException.class, () -> service.initierPaiement(demandeColis()));
        verifyNoInteractions(paiements, modes);
    }

    @Test
    void unAgentNePeutPasPayerPourUneAutreAgence() {
        Colis colis = mock(Colis.class);
        Agence depot = mock(Agence.class);
        Agence agenceAgent = mock(Agence.class);
        Employe employe = mock(Employe.class);
        Utilisateur utilisateur = mock(Utilisateur.class);
        when(colisRepo.findById("CLS-01")).thenReturn(Optional.of(colis));
        when(colis.getAgenceDepot()).thenReturn(depot);
        when(depot.getIdAgence()).thenReturn("AGC-YDE");
        when(utilisateurs.findByLogin("guichetier")).thenReturn(Optional.of(utilisateur));
        when(utilisateur.getEmploye()).thenReturn(employe);
        when(employe.getAgence()).thenReturn(agenceAgent);
        when(agenceAgent.getIdAgence()).thenReturn("AGC-DLA");
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                "guichetier", null, List.of(new SimpleGrantedAuthority("ROLE_GUICHETIER"))));

        assertThrows(BusinessException.class, () -> service.initierPaiement(demandeColis()));
        verifyNoInteractions(paiements, modes);
    }
}
