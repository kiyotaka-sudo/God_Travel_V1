package com.godtravel.backend.security;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JwtAuthenticationFilterTest {
    @Mock private JwtUtil jwtUtil;
    @Mock private CustomUserDetailsService users;
    @InjectMocks private JwtAuthenticationFilter filter;

    @AfterEach
    void clear() { SecurityContextHolder.clearContext(); }

    private MockHttpServletRequest authorizedRequest() {
        var request = new MockHttpServletRequest("GET", "/api/admin/stats");
        request.addHeader("Authorization", "Bearer signed-jwt");
        return request;
    }

    @Test
    void ancienJetonNeReactiveraPasUnCompteDesactive() throws Exception {
        when(jwtUtil.extractUsername("signed-jwt")).thenReturn("staff");
        when(users.loadUserByUsername("staff"))
                .thenReturn(new CustomUserDetails("USR-1", "staff", "hash", "ADMIN", null, "Staff", false));
        filter.doFilter(authorizedRequest(), new MockHttpServletResponse(), new MockFilterChain());
        assertNull(SecurityContextHolder.getContext().getAuthentication());
        verify(jwtUtil, never()).validateToken(anyString(), anyString());
    }

    @Test
    void compteSupprimeNeProvoquePasUneErreurServeur() throws Exception {
        when(jwtUtil.extractUsername("signed-jwt")).thenReturn("deleted");
        when(users.loadUserByUsername("deleted")).thenThrow(new UsernameNotFoundException("deleted"));
        filter.doFilter(authorizedRequest(), new MockHttpServletResponse(), new MockFilterChain());
        assertNull(SecurityContextHolder.getContext().getAuthentication());
    }
}
