package com.godtravel.backend.service;

import com.godtravel.backend.exception.BusinessException;
import com.godtravel.backend.exception.ResourceNotFoundException;
import com.godtravel.backend.model.dto.gps.PointageGpsDto;
import com.godtravel.backend.model.entity.*;
import com.godtravel.backend.repository.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GpsServiceAuthorizationTest {
    @Mock PositionGpsRepository positions;
    @Mock AlerteGpsRepository alertes;
    @Mock VoyageRepository voyages;
    @Mock UtilisateurRepository utilisateurs;
    @InjectMocks GpsService service;

    @AfterEach
    void clean() { SecurityContextHolder.clearContext(); }

    private void authenticate(String login, String role) {
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                login, null, List.of(new SimpleGrantedAuthority("ROLE_" + role))));
    }

    private PointageGpsDto point() {
        return PointageGpsDto.builder().idVoyage("VOY-1").idBalise("GPS-1")
                .latitude(new BigDecimal("3.867"))
                .longitude(new BigDecimal("11.517"))
                .vitesseKmh(80).build();
    }

    @Test
    void chauffeurNonAffecteNePeutPasEnregistrerDePosition() {
        authenticate("chauffeur", "CHAUFFEUR");
        Voyage voyage = mock(Voyage.class);
        Agence agence = mock(Agence.class);
        Agence agenceVoyage = mock(Agence.class);
        Employe employe = mock(Employe.class);
        Utilisateur user = mock(Utilisateur.class);
        when(voyages.findById("VOY-1")).thenReturn(Optional.of(voyage));
        when(utilisateurs.findByLogin("chauffeur")).thenReturn(Optional.of(user));
        when(user.getEmploye()).thenReturn(employe);
        when(employe.getAgence()).thenReturn(agence);
        when(employe.getStatutEmploye()).thenReturn("ACTIF");
        when(agence.getIdAgence()).thenReturn("AG-YDE");
        when(voyage.getAgence()).thenReturn(agenceVoyage);
        when(agenceVoyage.getIdAgence()).thenReturn("AG-YDE");
        when(voyage.getIdVoyage()).thenReturn("VOY-1");
        when(employe.getIdEmploye()).thenReturn("EMP-1");
        when(voyages.countChauffeurAffecte("VOY-1", "EMP-1")).thenReturn(0L);

        assertThrows(BusinessException.class, () -> service.enregistrerPosition(point()));
        verifyNoInteractions(positions);
    }

    @Test
    void administrateurNePeutPasAffecterUneBaliseAuMauvaisBus() {
        authenticate("admin", "ADMIN");
        Voyage voyage = mock(Voyage.class);
        Bus bus = mock(Bus.class);
        when(voyages.findById("VOY-1")).thenReturn(Optional.of(voyage));
        when(voyage.getBus()).thenReturn(bus);
        when(bus.getIdBus()).thenReturn("BUS-1");
        when(voyages.countBalisePourBus("GPS-1", "BUS-1")).thenReturn(0L);

        assertThrows(BusinessException.class, () -> service.enregistrerPosition(point()));
        verifyNoInteractions(positions);
    }

    @Test
    void chefAgenceNePeutPasAcquitterAlerteAutreAgence() {
        authenticate("chef", "CHEF_AGENCE");
        Utilisateur user = mock(Utilisateur.class);
        Employe employe = mock(Employe.class);
        Agence agence = mock(Agence.class);
        Agence agenceAlerte = mock(Agence.class);
        Voyage voyage = mock(Voyage.class);
        AlerteGps alerte = mock(AlerteGps.class);
        when(alertes.findById("ALT-1")).thenReturn(Optional.of(alerte));
        when(utilisateurs.findByLogin("chef")).thenReturn(Optional.of(user));
        when(user.getEmploye()).thenReturn(employe);
        when(employe.getAgence()).thenReturn(agence);
        when(employe.getStatutEmploye()).thenReturn("ACTIF");
        when(agence.getIdAgence()).thenReturn("AG-YDE");
        when(alerte.getVoyage()).thenReturn(voyage);
        when(voyage.getAgence()).thenReturn(agenceAlerte);
        when(agenceAlerte.getIdAgence()).thenReturn("AG-DLA");

        assertThrows(ResourceNotFoundException.class, () -> service.acquitterAlerte("ALT-1"));
        verify(alertes, never()).save(any());
    }
}
