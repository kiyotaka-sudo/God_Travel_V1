package com.godtravel.backend.security;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InMemoryRateLimiterTest {
    @Test
    void bloqueUneSerieTropRapideEtReprendApresUneMinute() {
        var limiter = new InMemoryRateLimiter();
        assertTrue(limiter.allow("auth:127.0.0.1", 2, 1_000L));
        assertTrue(limiter.allow("auth:127.0.0.1", 2, 2_000L));
        assertFalse(limiter.allow("auth:127.0.0.1", 2, 3_000L));
        assertTrue(limiter.allow("auth:127.0.0.1", 2, 61_000L));
    }

    @Test
    void refuseDeNouvellesAdressesLorsDeLaSaturationPuisRecupereApresExpiration() {
        var limiter = new InMemoryRateLimiter();
        for (int i = 0; i < 10_000; i++) {
            assertTrue(limiter.allow("auth:ip-" + i, 2, 1_000L));
        }
        assertFalse(limiter.allow("auth:nouvelle-ip", 2, 1_001L));
        assertTrue(limiter.allow("auth:ip-0", 2, 1_002L));
        assertTrue(limiter.allow("auth:nouvelle-ip", 2, 61_000L));
    }

    @Test
    void separeLesTypesDOperationsEtLesAdresses() {
        var limiter = new InMemoryRateLimiter();
        assertTrue(limiter.allow("auth:ip1", 1, 10L));
        assertFalse(limiter.allow("auth:ip1", 1, 11L));
        assertTrue(limiter.allow("lookup:ip1", 1, 11L));
        assertTrue(limiter.allow("auth:ip2", 1, 11L));
    }
}
