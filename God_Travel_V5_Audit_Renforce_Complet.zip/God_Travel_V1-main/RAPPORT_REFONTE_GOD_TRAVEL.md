# GOD TRAVEL — Rapport de refonte V3 et vérifications

**Date : 19 novembre 2026**  
**Source : archive God_Travel_V1-main.zip fournie par le propriétaire du projet.**  
**Livrable : code React/Vite + Spring Boot + SQL + tests + documentation, prêt à être commité dans GitHub, mais pas certifié pour le lancement commercial.**

## 1. Refonte visuelle et confort d'utilisation

- Page d’accueil premium : identité turquoise/bleu nuit, hiérarchie typographique éditoriale, appels à l’action lisibles, navigation responsive, services, horaires et itinéraire.
- Bus SVG original intégré au projet, paysage, roues et route animées ; scène 3D conservée avec affichage différé et repli statique sur appareils non compatibles.
- Contrôle pause/reprise du bus ; pause automatique lorsque l’onglet est masqué, animation désactivée en préférence « mouvement réduit », parallaxe limitée à une mise à jour par image (requestAnimationFrame).
- Focus clavier visible sur les liens d’accueil, boutons et commandes ; ajustements pour les petits écrans et thèmes clair/sombre.
- Chargement différé de la carte, sans confondre itinéraire illustratif et suivi GPS réel.

## 2. Réservation, sièges et tarification

- Sélection des voyages réservables uniquement (départ futur, statut ouvert, capacité, sièges disponibles, tarif positif) depuis une fonction métier testée.
- Gestion du numéro de siège et contrôle par verrou pessimiste sur la ligne Voyage pour sérialiser les ventes.
- Expiration logique à 10 minutes des réservations `EN_ATTENTE_PAIEMENT` avec retrait de la disponibilité ; migration SQL de l’index historique incompatible avec ces expirations.
- Webhook tardif / conflit de siège : paiement `A_VERIFIER` pour traitement humain, sans émission automatique d’un billet en doublon.
- **Correction V3 :** tarif adulte *actuellement en vigueur* dans la vue SQL ; les tarifs réduits ou expirés ne peuvent plus être repris implicitement. Les catégories autres que « adulte » sont bloquées jusqu’à mise en œuvre d’un tarif dédié.
- Annulation : contrôle de l’agence et verrou du voyage. Un billet encaissé ne peut pas être annulé sans procédure de remboursement formalisée.

## 3. Colis et contrôle d’accès

- Nouveau suivi public de colis avec code + téléphone, résultat DTO ne contenant ni pièce d’identité ni coordonnées personnelles.
- **Correction V3 :** consultation via POST (numéro absent de la chaîne de requête URL du navigateur) ; l’ancien accès GET public est supprimé.
- **Correction V3 :** liste minimale des agences via `/api/colis/agences`, ouverte aux guichetiers et chefs d’agence : le formulaire fret ne dépend plus du module admin réservé aux administrateurs.
- Enregistrement du départ, de l’arrivée et de la remise avec contrôles d’état, d’agence et de pièce d’identité.
- **Correction V3 :** une confirmation de paiement ne déclare plus automatiquement le colis « en transit » ; le départ exige une action opérationnelle distincte.
- **Correction V3 :** l’initiation d’un paiement colis est interdite aux comptes clients et aux agents des autres agences. Contrôle similaire ajouté aux paiements de billets au guichet.
- Autorisations GPS restreintes, détails internes colis visibles uniquement des rôles opérationnels.

## 4. Configuration et sécurité de démarrage

- Secrets JWT et HMAC absents du dépôt ; variables d’environnement exigées.
- **Correction V3 :** les comptes utilisateurs et le hash de mot de passe partagé présents dans l’ancien SQL sont retirés du script de démo. L’amorçage administrateur utilise un mot de passe local de 12 caractères minimum via `BootstrapAdminInitializer` et reste indépendant de l’injection des données de démonstration.
- **Correction V3 :** script séparé `database/schema_production.sql` sans données fictives ; référentiels métier à configurer par l’exploitant avant création de l’administrateur.
- **Correction V3 :** origines CORS configurables explicitement via `APP_CORS_ALLOWED_ORIGINS` pour un domaine HTTPS réel.
- **Correction V3 :** dates métier Java et fonction MySQL `NOW()` alignées sur `Africa/Douala` pour éviter les expirations de sièges décalées selon le fuseau du serveur.
- Tests JUnit ajoutés pour les refus de paiement colis non autorisé ; exécution attendue sur Maven/GitHub Actions.

## 5. Vérifications — résultats exacts

| Vérification | Résultat | Portée |
| --- | --- | --- |
| `npm test` | **12/12 réussis** | Tests unitaires de domaine JS sur Node 22 |
| Analyse de syntaxe TS/JS/JSX avec parseur TypeScript | **33 fichiers, 0 erreur, 0 import interne manquant** | Contrôle statique, non équivalent à un build |
| Parse CSS via `tinycss2` | **0 erreur de parsing** | Contrôle de syntaxe uniquement |
| `npm ci` / `npm run build` / `npm run lint` | **Non validés** | Dépendances non récupérables dans cet environnement (cache incomplet / réseau npm inaccessible) |
| `mvn test` / compilation Java | **Non validés** | Maven non installé dans cet environnement ; tests ajoutés mais non exécutés |
| MySQL / Monetbil / paiement réel | **Non validés** | Requiert un serveur, un jeu de données, des identifiants et un sandbox fournisseur |
| Visuel navigateur, audits WCAG/Lighthouse et charge | **Non mesurés** | Aucun score inventé |

L'automatisation `.github/workflows/ci.yml` lance tests, lint et build frontend et les tests Maven backend sur GitHub. Une exécution CI verte est **requise avant publication**.

## 6. Risques bloquants restant avant la production

1. Tests d'intégration MySQL avec transactions concurrentes (même siège, expiration, notification tardive, rollback).
2. Validation réelle du format de signature IPN Monetbil, idempotence durable, remboursements et réconciliation comptable.
3. Protection anti-abus du suivi colis et de la connexion (limitation de requêtes, audit journalisé, rotation des secrets).
4. Initialisation des vrais référentiels (agences, véhicules, catégories, tarifs, comptes équipe) et suppression/rotation des anciens identifiants.
5. Définition de la politique de confidentialité, conservation et suppression des données, conditions générales et contacts.
6. Tests navigateur multi-écrans, lecteurs d’écran, performances réelles, audit de sécurité et supervision serveur.
7. Hébergement séparé backend Java + base MySQL + HTTPS + sauvegardes. GitHub seul ne publie pas ce système complet.

**Conclusion :** une V3 substantiellement renforcée et documentée pour revue de code et intégration GitHub. Aucun résultat ne permet d’affirmer « plus parfait qu’Apple » ou « zéro bug ». La commercialisation nécessite la recette des points ci-dessus.
