import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, ArrowUpRight, Armchair, BusFront, MapPin, CircleHelp, Clock3, PackageCheck, ShieldCheck, Ticket, LoaderCircle, Menu, X, RefreshCcw } from 'lucide-react'
import { billetterieApi } from '@api/index'
import ScrollJourney from '@components/bus/ScrollJourney'
import HeroBusMotion from '@components/bus/HeroBusMotion'
import ThemeToggle from '@components/ThemeToggle'
import { useAuthStore } from '@store/authStore'
import { occupancyPercent, parseCmInstant, getBookableTrips, filterDepartures } from '@utils/domain'

const RouteMap = lazy(() => import('@components/RouteMap'))
const places = [{ name: 'Yaoundé · Mvan' }, { name: 'Boumnyébel' }, { name: 'Édéa' }, { name: 'Douala · Bépanda' }]
const number = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 })
const dateTime = (value) => value ? new Intl.DateTimeFormat('fr-FR', { timeZone: 'Africa/Douala', weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(parseCmInstant(value))) : 'Horaire non disponible'
const money = (value) => value != null ? `${number.format(value).replaceAll('\u202f', ' ')} XAF` : 'Tarif communiqué par l’agence'
const dataOf = (response) => response?.data?.data || []

export default function LandingPage() {
  const token = useAuthStore((state) => state.token)
  const user = useAuthStore((state) => state.user)
  const navigate = useNavigate()
  const [trips, setTrips] = useState([])
  const [loadingTrips, setLoadingTrips] = useState(true)
  const [tripError, setTripError] = useState('')
  const [selectedTrip, setSelectedTrip] = useState('')
  const [routeFilter, setRouteFilter] = useState('')
  const [dateFilter, setDateFilter] = useState('')
  const [visibleCount, setVisibleCount] = useState(4)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [requestVersion, setRequestVersion] = useState(0)
  const mapContainer = useRef(null)
  const [showMap, setShowMap] = useState(false)

  useEffect(() => {
    let active = true
    setLoadingTrips(true)
    setTripError('')
    billetterieApi.getVoyages().then((response) => { if (active) setTrips(dataOf(response)) })
      .catch((error) => { if (active) setTripError(error.response?.data?.message || 'Les départs ne peuvent pas être chargés pour le moment.') })
      .finally(() => { if (active) setLoadingTrips(false) })
    return () => { active = false }
  }, [requestVersion])

  useEffect(() => {
    if (!('IntersectionObserver' in window)) { setShowMap(true); return undefined }
    const observer = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) { setShowMap(true); observer.disconnect() }
    }, { rootMargin: '350px 0px' })
    if (mapContainer.current) observer.observe(mapContainer.current)
    return () => observer.disconnect()
  }, [])

  const departures = useMemo(() => getBookableTrips(trips), [trips])
  const routes = useMemo(() => [...new Set(departures.map((trip) => `${trip.villeDepart} → ${trip.villeArrivee}`))].sort(), [departures])
  const filteredDepartures = useMemo(() => filterDepartures(departures, { route: routeFilter, date: dateFilter }), [departures, routeFilter, dateFilter])
  const chosenTrip = useMemo(() => departures.find((trip) => String(trip.idVoyage) === selectedTrip), [departures, selectedTrip])
  useEffect(() => setVisibleCount(4), [routeFilter, dateFilter])
  // Les horaires et disponibilités doivent se rafraîchir même si la page reste ouverte.
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (!document.hidden) setRequestVersion((version) => version + 1)
    }, 60_000)
    return () => window.clearInterval(timer)
  }, [])
  const retryTrips = useCallback(() => setRequestVersion((version) => version + 1), [])
  const handleBooking = (event) => {
    event.preventDefault()
    const trip = chosenTrip
    if (!trip) return
    navigate(`/reserver?trip=${encodeURIComponent(trip.idVoyage)}`)
  }

  return <main className="landing-page">
    <a className="gt-skip-link" href="#reserver">Aller à la réservation</a>
    <header className="landing-nav gt-navigation">
      <Link to="/" className="landing-wordmark gt-wordmark" aria-label="God Travel, accueil"><img src="/god-travel-logo.jpg" alt="" /><span>God-<span>travel</span><small>UNITED EXPRESS</small></span></Link>
      <nav className={`landing-links ${mobileMenuOpen ? 'gt-nav-open' : ''}`} id="gt-site-nav" aria-label="Navigation principale" onClick={() => setMobileMenuOpen(false)}>
        <a href="#departures">Nos départs</a><a href="#voyage">L’expérience</a><a href="#route">Notre itinéraire</a><a href="#services">Services</a><Link to="/colis/suivi">Suivre un colis</Link>
        <Link className="gt-mobile-account" to={user?.role === 'ROLE_CLIENT' ? '/mon-espace' : '/connexion'}>{user?.role === 'ROLE_CLIENT' ? 'Mon espace' : 'Se connecter'}</Link>
      </nav>
      <div className="landing-account-links"><ThemeToggle compact />{user?.role === 'ROLE_CLIENT' ? <Link className="nav-signin" to="/mon-espace">Mon espace</Link> : <Link className="nav-signin" to="/connexion">Se connecter</Link>}<a className="nav-booking" href="#reserver">Réserver <ArrowUpRight size={16} /></a><Link className="landing-staff-link" to={token ? '/app' : '/login'}>{token && user?.role !== 'ROLE_CLIENT' ? 'Espace équipe' : 'Accès équipe'}</Link></div>
      <button type="button" className="gt-nav-toggle" aria-label={mobileMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'} aria-controls="gt-site-nav" aria-expanded={mobileMenuOpen} onClick={() => setMobileMenuOpen((open) => !open)}>{mobileMenuOpen ? <X size={21} /> : <Menu size={21} />}</button>
    </header>

    <section className="gt-premium-hero" aria-labelledby="gt-hero-title">
      <div className="gt-hero-backdrop" aria-hidden="true" />
      <div className="gt-hero-copy">
        <p className="gt-hero-eyebrow"><span className="gt-signal-dot" /> UNITED EXPRESS · CAMEROUN</p>
        <h1 id="gt-hero-title">Le voyage a <span>une autre</span> allure.</h1>
        <p className="gt-hero-subtitle">Entre Yaoundé et Douala, chaque départ mérite une expérience plus simple, plus belle et mieux préparée.</p>
        <div className="gt-hero-actions"><a className="gt-hero-primary" href="#reserver">Trouver mon départ <ArrowUpRight size={20} /></a><a className="gt-hero-secondary" href="#voyage">Découvrir l’expérience <ArrowRight size={18} /></a></div>
        <div className="gt-hero-trust" aria-label="Services disponibles"><span><ShieldCheck size={17} /> Billets vérifiables</span><span><Armchair size={17} /> Choix du siège</span><span><Ticket size={17} /> Paiement mobile</span></div>
      </div>
      <HeroBusMotion />
      <div className="gt-hero-bottom"><span>01 — L’EXPÉRIENCE GOD TRAVEL</span><span>YAOUNDÉ <i /> DOUALA</span><a href="#voyage">DÉCOUVRIR <ArrowRight size={14} /></a></div>
    </section>

    <ScrollJourney />

    <section className="editorial-intro"><div className="section-kicker">LE VOYAGE, EN TOUTE CLARTÉ</div><h2>Voyagez. Explorez.<br /><em>Arrivez.</em></h2><p>Un trajet interurbain se prépare avec des horaires lisibles, un siège choisi et un billet que vous pouvez retrouver avant le départ.</p></section>

    <section className="booking-section" id="reserver"><div className="booking-intro"><div className="section-kicker">RÉSERVATION EN LIGNE</div><h2>Votre prochain départ,<br /><em>en quelques étapes.</em></h2><p>Choisissez un départ réellement publié. Un compte voyageur est requis pour réserver et payer en ligne.</p><Link to="/inscription" className="story-inline-link">Créer un compte voyageur <ArrowRight size={15} /></Link></div><form className="landing-search" onSubmit={handleBooking}><label>Départ<select value={selectedTrip} required onChange={(event) => setSelectedTrip(event.target.value)}><option value="">Choisir un départ disponible</option>{departures.map((trip) => <option key={trip.idVoyage} value={trip.idVoyage}>{trip.villeDepart} → {trip.villeArrivee} · {dateTime(trip.dateHeureDepartPrevue)}</option>)}</select></label><label>Arrivée<span className="search-readonly">{chosenTrip?.villeArrivee || 'Selon le départ choisi'}</span></label><label>Date et heure<span className="search-readonly">{dateTime(chosenTrip?.dateHeureDepartPrevue)}</span></label><div className="landing-search-price"><span>Tarif du départ</span><strong>{money(chosenTrip?.tarifBaseXaf)}</strong></div><button className="button-primary" disabled={loadingTrips || departures.length === 0 || !chosenTrip}>{loadingTrips ? <LoaderCircle className="spin" size={16} /> : 'Continuer'} <ArrowRight size={16} /></button>{tripError && <p className="inline-error" role="alert">{tripError} <button type="button" className="gt-retry-inline" onClick={retryTrips}><RefreshCcw size={13} /> Réessayer</button></p>}{!loadingTrips && !tripError && departures.length === 0 && <p className="inline-empty">Aucun départ n’est disponible actuellement. Consultez l’agence pour connaître les prochains horaires.</p>}</form></section>

    <section className="departures-section" id="departures">
      <div className="section-heading-row"><div><div className="section-kicker">HORAIRES PUBLIÉS</div><h2>Prochains départs</h2><p>Consultez les horaires et disponibilités réellement publiés par l’agence.</p></div><Link className="text-action" to="/reserver">Réserver un départ <ArrowRight size={15} /></Link></div>
      {!loadingTrips && !tripError && departures.length > 0 && <div className="departure-filters" aria-label="Filtrer les prochains départs">
        <label>Mon trajet
          <select value={routeFilter} onChange={(event) => setRouteFilter(event.target.value)}><option value="">Tous les itinéraires</option>{routes.map((route) => <option key={route} value={route}>{route}</option>)}</select>
        </label>
        <label>Le jour du départ
          <input type="date" value={dateFilter} onChange={(event) => setDateFilter(event.target.value)} />
        </label>
        <div className="departure-filter-actions"><span role="status" aria-live="polite">{filteredDepartures.length} départ{filteredDepartures.length !== 1 ? 's' : ''} trouvé{filteredDepartures.length !== 1 ? 's' : ''}</span>{(routeFilter || dateFilter) && <button type="button" onClick={() => { setRouteFilter(''); setDateFilter('') }}>Effacer les filtres <X size={14} /></button>}</div>
      </div>}
      {loadingTrips ? <div className="landing-loading" role="status"><LoaderCircle className="spin" /> Chargement des départs…</div>
        : tripError ? <div className="landing-error" role="alert">{tripError}<button className="button-secondary" type="button" onClick={retryTrips}><RefreshCcw size={15} /> Réessayer</button></div>
        : departures.length === 0 ? <div className="landing-empty"><BusFront size={21} /><strong>Pas de départ affiché pour le moment</strong><span>Les horaires apparaîtront ici dès leur publication par l’agence.</span></div>
        : filteredDepartures.length === 0 ? <div className="landing-empty"><BusFront size={21} /><strong>Aucun départ ne correspond à ces filtres</strong><span>Essayez un autre jour ou itinéraire.</span><button className="button-secondary" onClick={() => { setRouteFilter(''); setDateFilter('') }}>Voir tous les départs</button></div>
        : <><div className="departure-teasers">{filteredDepartures.slice(0, visibleCount).map((trip) => <article className="departure-teaser" key={trip.idVoyage}><span className="departure-teaser-time"><Clock3 size={14} /> {dateTime(trip.dateHeureDepartPrevue)}</span><div className="departure-teaser-route"><strong>{trip.villeDepart}</strong><span>→</span><strong>{trip.villeArrivee}</strong><small>{trip.busImmatriculation || 'Bus non renseigné'} · {trip.classeBus || 'Classe non renseignée'}</small></div><div className="departure-teaser-capacity"><span>{trip.placesRestantes ?? '—'} place(s) restante(s)</span><div><i style={{ width: `${occupancyPercent(trip.placesOccupees, trip.capaciteTotale)}%` }} /></div></div><strong className="departure-teaser-price">{money(trip.tarifBaseXaf)}</strong><button className="icon-link-button" type="button" onClick={() => navigate(`/reserver?trip=${encodeURIComponent(trip.idVoyage)}`)} aria-label={`Choisir le départ ${trip.villeDepart} vers ${trip.villeArrivee}`}><ArrowRight size={17} /></button></article>)}</div>{filteredDepartures.length > visibleCount && <button type="button" className="gt-show-more" onClick={() => setVisibleCount((count) => count + 4)}>Afficher plus de départs <ArrowRight size={16} /></button>}</>}
    </section>

    <section className="service-strip" id="services"><div className="section-kicker">LES SERVICES</div><h2>Le trajet et <em>ce qui l’accompagne.</em></h2><div className="service-grid"><article><Armchair /><span>01</span><h3>Votre siège</h3><p>La disponibilité du siège est vérifiée depuis le plan du départ sélectionné.</p></article><article><Ticket /><span>02</span><h3>Votre billet</h3><p>Après paiement confirmé, retrouvez le billet nominatif et son QR associé à la réservation.</p></article><article><PackageCheck /><span>03</span><h3>Fret et colis</h3><p>Le suivi de colis se fait auprès de l’agence avec son code. Les tarifs sont confirmés au guichet. <Link to="/colis/suivi" className="story-inline-link">Suivre mon colis <ArrowRight size={14} /></Link></p></article><article><ShieldCheck /><span>04</span><h3>Paiement mobile</h3><p>Le statut du paiement est confirmé par la notification de l’opérateur.</p></article></div><div className="service-note"><CircleHelp size={15} /> Les packs, la fidélité, le devis de fret et le fonctionnement hors ligne ne sont pas disponibles dans l’API actuelle.</div></section>

    <section className="route-section" id="route"><div className="route-intro"><div className="section-kicker">L’ITINÉRAIRE</div><h2>La Nationale 3,<br /><em>entre deux villes.</em></h2><p>Repères indicatifs sur l’axe Yaoundé–Douala. Cette carte présente le parcours géographique, pas la position en direct d’un véhicule.</p><div className="route-stops">{places.map((place) => <span key={place.name}><i /> {place.name}</span>)}</div></div><div className="landing-map-wrap" ref={mapContainer}>{showMap ? <Suspense fallback={<div className="route-map-placeholder">Chargement de la carte…</div>}><RouteMap /></Suspense> : <div className="route-map-placeholder"><MapPin size={21} /> Itinéraire Yaoundé — Douala</div>}</div></section>

    <section className="final-cta"><div className="section-kicker">PRÊT POUR LE DÉPART ?</div><h2>Choisissez un horaire.<br /><em>À vous de choisir la place.</em></h2><p>Connectez-vous à votre compte voyageur pour réserver et suivre le statut du paiement.</p><Link className="button-primary" to="/reserver">Consulter les départs <ArrowRight size={16} /></Link></section>
    <footer className="landing-footer"><Link to="/" className="footer-mark">God-travel<span>UNITED EXPRESS · CAMEROUN</span></Link><Link to="/confidentialite">Confidentialité</Link><Link to="/billet">Retrouver un billet</Link><Link to="/colis/suivi">Suivre un colis</Link><span>Voyagez · Explorez · Arrivez</span></footer>
  </main>
}
