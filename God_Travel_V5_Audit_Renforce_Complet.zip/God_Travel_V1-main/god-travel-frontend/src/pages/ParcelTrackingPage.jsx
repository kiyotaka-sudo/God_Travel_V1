import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Check, Clock3, LoaderCircle, MapPin, PackageCheck, RefreshCcw, ShieldCheck, Truck } from 'lucide-react'
import { colisApi } from '@api/index'
import { isValidCmMobile, normalizeCmPhone, parseCmInstant } from '@utils/domain'

const stages = [
  { key: 'ENREGISTRE', name: 'Enregistré à l’agence', description: 'Votre colis a été pris en charge.' },
  { key: 'EN_TRANSIT', name: 'En transit', description: 'Le transport est en cours.' },
  { key: 'ARRIVE_AGENCE', name: 'Arrivé à destination', description: 'Contactez l’agence de retrait pour les modalités.' },
  { key: 'LIVRE', name: 'Remis au destinataire', description: 'Le retrait a été enregistré.' },
]

const statusIndex = (value) => stages.findIndex((stage) => stage.key === String(value || '').toUpperCase())
const niceDate = (value) => {
  const timestamp = parseCmInstant(value)
  return Number.isFinite(timestamp) ? new Intl.DateTimeFormat('fr-FR', { timeZone: 'Africa/Douala', dateStyle: 'long', timeStyle: 'short' }).format(new Date(timestamp)) : 'Date non communiquée'
}

export default function ParcelTrackingPage() {
  const [params] = useSearchParams()
  const [code, setCode] = useState(params.get('code') || '')
  const [telephone, setTelephone] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const stage = result?.statut === 'RETENU' ? 2 : statusIndex(result?.statut)
  const held = result?.statut === 'RETENU'

  const submit = async (event) => {
    event.preventDefault()
    if (!code.trim() || !isValidCmMobile(telephone)) {
      setError('Indiquez votre code de suivi et un numéro camerounais valide (9 chiffres commençant par 6).')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const response = await colisApi.suivrePublic(code.trim().toUpperCase(), normalizeCmPhone(telephone))
      const data = response.data?.data
      if (!data?.codeSuivi) throw new Error('Le serveur n’a pas renvoyé de suivi exploitable.')
      setResult(data)
    } catch (requestError) {
      if ([403, 404].includes(requestError.response?.status)) {
        setError('Aucun colis retrouvé avec ces informations. Vérifiez le code et le numéro utilisé lors du dépôt ou du retrait.')
      } else {
        setError(requestError.response?.data?.message || requestError.message || 'Le suivi est momentanément indisponible. Réessayez.')
      }
    } finally { setLoading(false) }
  }

  return <main className="parcel-page">
    <header className="ticket-public-nav"><Link to="/" className="landing-wordmark"><img src="/god-travel-logo.jpg" alt="" /><span>God-<span>travel</span></span></Link><Link to="/" className="ticket-back-link"><ArrowLeft size={15} /> Retour à l’accueil</Link></header>
    <div className="parcel-shell">
      <section className="parcel-intro"><span className="section-kicker"><PackageCheck size={16} /> SUIVI COLIS · GOD TRAVEL</span><h1>De nos mains,<br /><em>jusqu’aux vôtres.</em></h1><p>Un suivi simple pour savoir où en est votre envoi entre les agences God Travel. Les informations de suivi proviennent du système d’expédition.</p><div className="parcel-safety"><ShieldCheck size={18} /><span>Votre numéro de téléphone est utilisé uniquement pour retrouver le colis. Il n’est pas affiché dans le résultat.</span></div></section>
      <section className="parcel-card" aria-labelledby="parcel-title"><div className="parcel-card-top"><span>01 / CONSULTATION</span><Truck size={21} /></div><h2 id="parcel-title">Retrouvez votre envoi</h2><p>Munissez-vous de votre référence et du téléphone de l’expéditeur ou du destinataire.</p>
        <form onSubmit={submit} className="parcel-form"><label htmlFor="parcel-code">Code de suivi<input id="parcel-code" autoCapitalize="characters" autoComplete="off" required maxLength={30} value={code} onChange={(event) => setCode(event.target.value)} placeholder="TRK-XXXX-XXXXXX" /></label><label htmlFor="parcel-phone">Téléphone lié au colis<input id="parcel-phone" type="tel" autoComplete="tel" inputMode="tel" required value={telephone} onChange={(event) => setTelephone(event.target.value)} placeholder="6 99 00 00 00" /></label><button className="button-primary" type="submit" disabled={loading}>{loading ? <><LoaderCircle size={17} className="spin" /> Recherche…</> : <>Suivre mon colis <ArrowRight size={17} /></>}</button></form>
        {error && <div className="parcel-error" role="alert"><RefreshCcw size={18} /> {error}</div>}
      </section>
      {result && <section className="parcel-result" role="status" aria-live="polite"><div className="parcel-result-head"><div><span>RÉFÉRENCE CONFIRMÉE</span><h2>{result.codeSuivi}</h2></div><span className={`parcel-status ${held ? 'is-held' : ''}`}>{held ? 'En attente de vérification à l’agence' : stages[stage]?.name || result.statut}</span></div><div className="parcel-route"><div><MapPin size={18} /><span>Origine</span><strong>{result.villeDepart || 'Agence de départ'}</strong></div><ArrowRight size={23} /><div><MapPin size={18} /><span>Destination</span><strong>{result.villeArrivee || 'Agence d’arrivée'}</strong></div></div><div className="parcel-timeline">{stages.map((item, i) => <div className={`parcel-milestone ${stage >= i ? 'is-complete' : ''}`} key={item.key}><span className="parcel-marker">{stage >= i ? <Check size={15} /> : <Clock3 size={15} />}</span><div><strong>{item.name}</strong><small>{i === 0 && result.dateEnregistrement ? niceDate(result.dateEnregistrement) : i === 3 && result.dateRemise ? niceDate(result.dateRemise) : item.description}</small></div></div>)}</div>{held && <p className="parcel-error" role="alert">Votre colis nécessite une vérification en agence avant tout retrait.</p>}<p className="parcel-disclaimer">Ce suivi affiche uniquement les états enregistrés par l’agence. La disponibilité du retrait et l’identité du destinataire doivent être confirmées au guichet.</p></section>}
      <div className="parcel-help"><span>Une question concernant votre colis ?</span><p>Munissez-vous de votre code de suivi et contactez votre agence de dépôt ou de retrait.</p><Link to="/">Retour au site <ArrowRight size={15} /></Link></div>
    </div>
  </main>
}
