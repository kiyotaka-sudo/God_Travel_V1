import { useCallback, useEffect, useState } from 'react'
import { ArrowRight, LoaderCircle, Package, PackageCheck, Plus, Search, Truck } from 'lucide-react'
import toast from 'react-hot-toast'
import { colisApi } from '@api/index'
import { useAuthStore } from '@store/authStore'

const dataOf = (response) => response?.data?.data
const amount = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 })

export default function ColisPage() {
  const role = useAuthStore((state) => state.user?.role)
  const agenceConnectee = useAuthStore((state) => state.user?.agenceId)
  const canDepart = (colis) => role === 'ROLE_ADMIN' || (agenceConnectee && agenceConnectee === colis?.agenceDepot?.idAgence)
  const canRecevoir = (colis) => role === 'ROLE_ADMIN' || (agenceConnectee && agenceConnectee === colis?.agenceRetrait?.idAgence)
  const canManage = ['ROLE_ADMIN', 'ROLE_CHEF_AGENCE', 'ROLE_GUICHETIER'].includes(role)
  const [items, setItems] = useState([])
  const [agencies, setAgencies] = useState([])
  const [agencyError, setAgencyError] = useState('')
  const [query, setQuery] = useState('')
  const [tracking, setTracking] = useState('')
  const [tracked, setTracked] = useState(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ nomExpediteur: '', telephoneExpediteur: '', idAgenceRetrait: '', nomDestinataire: '', prenomDestinataire: '', telephoneDestinataire: '', cniDestinataire: '', descriptionContenu: '', poidsKg: '', valeurDeclaree: '', fraisExpedition: '' })

  const load = useCallback(async () => {
    setLoading(true); setError('')
    try { setItems(dataOf(await colisApi.listerColis()) || []) }
    catch (e) { setError(e.response?.data?.message || 'Impossible de charger les colis.'); setItems([]) }
    finally { setLoading(false) }
  }, [])
  useEffect(() => { load() }, [load])
  useEffect(() => {
    if (!canManage) return
    colisApi.getAgences().then((response) => setAgencies(dataOf(response) || [])).catch((e) => setAgencyError(e.response?.data?.message || 'La liste des agences n’est pas accessible.'))
  }, [canManage])

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))
  const create = async (event) => {
    event.preventDefault(); setBusy(true); setError('')
    try {
      const request = { ...form, poidsKg: Number(form.poidsKg), valeurDeclaree: form.valeurDeclaree === '' ? null : Number(form.valeurDeclaree), fraisExpedition: Number(form.fraisExpedition) }
      await colisApi.enregistrerColis(request)
      toast.success('Colis enregistré. Le code de suivi est disponible dans la liste.')
      setForm({ nomExpediteur: '', telephoneExpediteur: '', idAgenceRetrait: '', nomDestinataire: '', prenomDestinataire: '', telephoneDestinataire: '', cniDestinataire: '', descriptionContenu: '', poidsKg: '', valeurDeclaree: '', fraisExpedition: '' })
      await load()
    } catch (e) { const message = e.response?.data?.message || 'L’enregistrement du colis a échoué.'; setError(message); toast.error(message) }
    finally { setBusy(false) }
  }
  const searchTracking = async (event) => {
    event.preventDefault(); setTracked(null); setError('')
    try { setTracked(dataOf(await colisApi.suivreColis(tracking.trim()))) }
    catch (e) { setError(e.response?.data?.message || 'Aucun colis trouvé pour ce code.') }
  }
  const changeState = async (item, action) => {
    setBusy(true); setError('')
    try {
      if (action === 'depart') await colisApi.departColis(item.idColis)
      if (action === 'arrivee') await colisApi.arriveeColis(item.idColis)
      toast.success(action === 'depart' ? 'Départ du colis enregistré.' : 'Arrivée en agence enregistrée.')
      await load()
    } catch (e) {
      const message = e.response?.data?.message || 'La mise à jour du colis a échoué.'
      setError(message); toast.error(message)
    } finally { setBusy(false) }
  }

  const deliver = async (item) => {
    const cni = window.prompt('Saisissez le numéro de CNI présenté par le destinataire :')
    if (!cni?.trim()) return
    setBusy(true)
    try { await colisApi.remettreColis(item.idColis, { cniDestinataire: cni.trim() }); toast.success('Remise enregistrée.'); await load() }
    catch (e) { const message = e.response?.data?.message || 'La remise n’a pas pu être enregistrée.'; setError(message); toast.error(message) }
    finally { setBusy(false) }
  }

  const visible = items.filter((item) => [item.codeSuivi, item.nomDestinataire, item.descriptionContenu, item.statutColis].filter(Boolean).join(' ').toLowerCase().includes(query.toLowerCase()))
  const fields = [['nomExpediteur', 'Nom de l’expéditeur'], ['telephoneExpediteur', 'Téléphone expéditeur'], ['nomDestinataire', 'Nom du destinataire'], ['prenomDestinataire', 'Prénom destinataire'], ['telephoneDestinataire', 'Téléphone destinataire'], ['cniDestinataire', 'CNI du destinataire']]
  return <main className="admin-page parcels-page"><header className="admin-page-heading"><div><span className="admin-eyebrow">SERVICE FRET</span><h1>Colis & suivi</h1><p>Enregistrements et statuts récupérés depuis l’API.</p></div></header>
    {error && <div className="office-alert" role="alert">{error}</div>}
    <section className="parcel-tracking-card"><div><span className="admin-eyebrow">SUIVI CLIENT</span><h2>Retrouver un colis</h2><p>Le code de suivi permet de consulter le statut retourné par le serveur.</p></div><form onSubmit={searchTracking}><label htmlFor="tracking-code">Code de suivi<input id="tracking-code" required value={tracking} onChange={(e) => setTracking(e.target.value.toUpperCase())} placeholder="TRK-…" /></label><button className="button-primary"><Search size={15} /> Suivre</button></form>{tracked && <div className="parcel-tracking-result"><PackageCheck size={18} /><strong>{tracked.codeSuivi}</strong><span>{tracked.statutColis}</span><span>{tracked.descriptionContenu}</span></div>}</section>
    {canManage && <section className="admin-panel parcel-create-panel"><div className="panel-heading"><div><span className="admin-eyebrow">NOUVEL ENVOI</span><h2>Enregistrer un colis</h2></div><Plus size={18} /></div>{agencyError && <p className="office-alert">{agencyError}</p>}<form className="parcel-create-form" onSubmit={create}><div className="parcel-form-grid">{fields.map(([key, label]) => <label key={key}>{label}<input required={key !== 'prenomDestinataire'} value={form[key]} onChange={(e) => update(key, e.target.value)} /></label>)}<label>Agence de retrait<select required value={form.idAgenceRetrait} onChange={(e) => update('idAgenceRetrait', e.target.value)}><option value="">Choisir une agence</option>{agencies.map((agency) => <option key={agency.idAgence} value={agency.idAgence}>{agency.nomAgence}</option>)}</select></label><label>Description<input required value={form.descriptionContenu} onChange={(e) => update('descriptionContenu', e.target.value)} /></label><label>Poids (kg)<input required min="0.1" step="0.1" type="number" value={form.poidsKg} onChange={(e) => update('poidsKg', e.target.value)} /></label><label>Valeur déclarée (XAF)<input min="0" step="1" type="number" value={form.valeurDeclaree} onChange={(e) => update('valeurDeclaree', e.target.value)} /></label><label>Frais confirmés par l’agence (XAF)<input required min="0" step="1" type="number" value={form.fraisExpedition} onChange={(e) => update('fraisExpedition', e.target.value)} /></label></div><p className="privacy-note">Le backend ne fournit pas de calculateur tarifaire ni de confirmation d’envoi SMS. Saisissez les frais validés par l’agence.</p><button className="button-primary" disabled={busy || !canManage || agencies.length === 0}>{busy ? 'Enregistrement…' : 'Enregistrer le colis'} <ArrowRight size={15} /></button></form></section>}
    <section className="admin-panel parcel-list-panel"><div className="panel-heading"><div><span className="admin-eyebrow">REGISTRE</span><h2>Colis enregistrés</h2></div><div className="parcel-list-tools"><span>{visible.length} élément(s)</span><input aria-label="Filtrer les colis" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Code, destinataire, statut" /></div></div>{loading ? <div className="admin-empty"><LoaderCircle className="spin" /> Chargement des colis…</div> : error && items.length === 0 ? <div className="admin-empty">{error}</div> : visible.length ? <div className="parcel-list">{visible.map((item) => <article className="parcel-row" key={item.idColis}><div className="parcel-row-icon"><Package size={18} /></div><div className="parcel-row-main"><strong>{item.codeSuivi}</strong><span>{item.descriptionContenu || 'Description non fournie'}</span><small>{item.nomDestinataire} · {item.telephoneDestinataire}</small></div><div className="parcel-row-meta"><span>{item.statutColis}</span><small>{item.poidsKg} kg · {amount.format(item.fraisExpeditionXaf || 0)} XAF</small></div>{canManage && canDepart(item) && item.statutColis === 'ENREGISTRE' && <button type="button" className="icon-link-button" onClick={() => changeState(item, 'depart')} disabled={busy} title="Enregistrer le départ" aria-label={`Enregistrer le départ du colis ${item.codeSuivi}`}><Truck size={16} /></button>}{canManage && canRecevoir(item) && item.statutColis === 'EN_TRANSIT' && <button type="button" className="icon-link-button" onClick={() => changeState(item, 'arrivee')} disabled={busy} title="Colis reçu à destination" aria-label={`Enregistrer l'arrivée du colis ${item.codeSuivi}`}><PackageCheck size={16} /></button>}{canManage && canRecevoir(item) && item.statutColis === 'ARRIVE_AGENCE' && <button type="button" className="icon-link-button" onClick={() => deliver(item)} disabled={busy} title="Vérifier l'identité et remettre" aria-label={`Remettre le colis ${item.codeSuivi}`}><Truck size={16} /></button>}</article>)}</div> : <div className="admin-empty"><Package size={21} />Aucun colis ne correspond à ce filtre.</div>}</section>
  </main>
}
