import { MapContainer, TileLayer, Polyline, CircleMarker, Tooltip } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

const routeN3 = [[3.848, 11.502], [3.78, 11.38], [3.75, 11.15], [3.85, 11.02], [3.8, 10.13], [3.98, 9.92], [4.051, 9.768]]
const stops = [{ point: routeN3[0], name: 'Yaoundé · Mvan' }, { point: routeN3[3], name: 'Boumnyébel' }, { point: routeN3[4], name: 'Édéa' }, { point: routeN3[6], name: 'Douala · Bépanda' }]

export { stops }

export default function RouteMap() {
  return <><MapContainer className="landing-map" center={[3.9, 10.65]} zoom={7} scrollWheelZoom={false} attributionControl>
    <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
    <Polyline positions={routeN3} pathOptions={{ color: '#14b2b6', weight: 4, opacity: .85 }} />
    {stops.map((place) => <CircleMarker key={place.name} center={place.point} radius={6} pathOptions={{ color: '#0b1417', weight: 2, fillColor: '#14b2b6', fillOpacity: 1 }}><Tooltip>{place.name}</Tooltip></CircleMarker>)}
  </MapContainer><div className="map-caption"><span className="map-live-dot" /><span>ITINÉRAIRE INDICATIF</span><span>Yaoundé → Douala</span></div></>
}
