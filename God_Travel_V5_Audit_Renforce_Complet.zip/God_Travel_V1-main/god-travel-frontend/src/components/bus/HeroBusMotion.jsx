import { useEffect, useRef, useState } from 'react'
import { Pause, Play } from 'lucide-react'

/**
 * Illustration locale du bus : aucun téléchargement d'image ou moteur 3D supplémentaire.
 * Animation décorative uniquement ; le parcours réel est indiqué sur la carte plus bas.
 */
export default function HeroBusMotion() {
  const [paused, setPaused] = useState(() => window.sessionStorage.getItem('godtravel:pause-bus') === '1')
  const [inactive, setInactive] = useState(() => document.hidden)
  const [offscreen, setOffscreen] = useState(false)
  const visualRef = useRef(null)
  const [reduced, setReduced] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  const animationFrame = useRef(0)
  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)')
    const updateMotion = () => setReduced(query.matches)
    const updateVisibility = () => setInactive(document.hidden)
    query.addEventListener?.('change', updateMotion)
    document.addEventListener('visibilitychange', updateVisibility)
    const observer = 'IntersectionObserver' in window ? new IntersectionObserver(
      ([entry]) => setOffscreen(!entry?.isIntersecting), { threshold: 0.01 }) : null
    if (observer && visualRef.current) observer.observe(visualRef.current)
    return () => {
      query.removeEventListener?.('change', updateMotion)
      document.removeEventListener('visibilitychange', updateVisibility)
      observer?.disconnect()
      window.cancelAnimationFrame(animationFrame.current)
    }
  }, [])
  useEffect(() => { window.sessionStorage.setItem('godtravel:pause-bus', paused ? '1' : '0') }, [paused])
  const motionStopped = paused || inactive || offscreen || reduced
  const move = (event) => {
    if (motionStopped || event.pointerType === 'touch') return
    const target = event.currentTarget
    const rect = target.getBoundingClientRect()
    const x = (event.clientX - rect.left) / rect.width - 0.5
    const y = (event.clientY - rect.top) / rect.height - 0.5
    window.cancelAnimationFrame(animationFrame.current)
    animationFrame.current = window.requestAnimationFrame(() => {
      target.style.setProperty('--gt-parallax-x', `${Math.round(x * 19)}px`)
      target.style.setProperty('--gt-parallax-y', `${Math.round(y * 12)}px`)
    })
  }
  const reset = (event) => {
    window.cancelAnimationFrame(animationFrame.current)
    event.currentTarget.style.setProperty('--gt-parallax-x', '0px')
    event.currentTarget.style.setProperty('--gt-parallax-y', '0px')
  }
  return <div ref={visualRef} className={`gt-hero-visual ${motionStopped ? 'gt-motion-paused' : ''}`} onPointerMove={move} onPointerLeave={reset}>
    <div className="gt-visual-mesh" aria-hidden="true" />
    <div className="gt-visual-header" aria-hidden="true"><span>GOD TRAVEL / EXPERIENCE 01</span><span>ROUTE NATIONALE 03</span></div>
    <div className="gt-orbit gt-orbit-one" aria-hidden="true" /><div className="gt-orbit gt-orbit-two" aria-hidden="true" />
    <svg className="gt-hero-landscape" viewBox="0 0 800 460" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#16475A"/><stop offset="1" stopColor="#04303D"/></linearGradient>
        <linearGradient id="hill" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#2D6975"/><stop offset="1" stopColor="#11414E"/></linearGradient>
      </defs>
      <path d="M0 255 L92 204 177 248 258 174 348 234 424 174 504 224 588 162 685 216 800 150 800 460 0 460Z" fill="url(#hill)" opacity=".68"/>
      <path d="M0 318 L107 267 209 299 329 239 425 286 532 231 628 272 800 207 800 460 0 460Z" fill="#082F3C" opacity=".95"/>
      <path d="M0 385 Q165 320 312 350 T800 287 L800 460 0 460Z" fill="#092733"/>
      <circle cx="618" cy="119" r="87" fill="#E9D8A8" opacity=".085"/><circle cx="618" cy="119" r="47" fill="#F0D9A4" opacity=".24"/>
    </svg>
    <div className="gt-bus-parallax" aria-hidden="true"><div className="gt-bus-visual-wrap">
      <svg className="gt-bus-svg" viewBox="0 0 780 325" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="bus-body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFFFFF"/><stop offset=".52" stopColor="#F6FBFA"/><stop offset="1" stopColor="#D9EAE9"/></linearGradient>
          <linearGradient id="glass-panel" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#153843"/><stop offset=".6" stopColor="#071E29"/><stop offset="1" stopColor="#1F5663"/></linearGradient>
          <linearGradient id="bus-stripe" x1="0" y1="0" x2="1" y2="0"><stop stopColor="#0A8F9A"/><stop offset=".58" stopColor="#2FD6D4"/><stop offset="1" stopColor="#049BA7"/></linearGradient>
          <filter id="bus-drop" x="-30%" y="-50%" width="160%" height="200%"><feGaussianBlur stdDeviation="11"/></filter>
        </defs>
        <ellipse cx="389" cy="286" rx="332" ry="18" fill="#00171C" opacity=".55" filter="url(#bus-drop)"/>
        <path d="M60 76 Q64 44 105 38 L619 32 Q650 33 669 58 L719 128 Q729 139 729 161 L729 247 Q729 264 704 265 L63 265 Q41 262 40 238 L40 109 Q39 86 60 76Z" fill="url(#bus-body)" stroke="#A9C9CB" strokeWidth="4"/>
        <path d="M60 76 Q64 44 105 38 L619 32 Q650 33 669 58 L719 128 728 146 L39 146 40 109 Q39 86 60 76Z" fill="#FDFEFE" opacity=".64"/>
        <path d="M76 85 Q78 64 102 60 L608 55 Q631 55 643 75 L682 132 60 132 60 104Q60 92 76 85Z" fill="url(#glass-panel)" stroke="#C9E7E7" strokeWidth="5"/>
        <path d="M644 74L681 131H648L633 59Z" fill="#93CBD0" opacity=".36"/>
        {[159, 264, 369, 474, 579].map((x) => <path key={x} d={`M${x} 58L${x - 11} 134`} stroke="#D6E9E9" strokeWidth="7" opacity=".95"/>)}
        <path d="M82 72L102 62 123 62 83 129H67Z" fill="#C7F5F2" opacity=".16"/>
        <path d="M191 62L227 62 190 128 155 128Z" fill="#D5FAFA" opacity=".13"/>
        <path d="M74 149H726L726 168Q440 179 40 185L40 169Z" fill="url(#bus-stripe)"/>
        <path d="M43 221Q365 229 728 204L728 244Q726 260 702 263L63 263Q42 260 42 241Z" fill="#B1D3D4" opacity=".55"/>
        <path d="M72 197H286" stroke="#7AABB0" strokeWidth="1.5" opacity=".45"/>
        <path d="M411 197H614" stroke="#7AABB0" strokeWidth="1.5" opacity=".45"/>
        <text x="330" y="208" fill="#0B3D47" fontFamily="Arial, sans-serif" fontSize="35" fontStyle="italic" fontWeight="800" letterSpacing="-1.8">God-</text>
        <text x="412" y="208" fill="#079EAB" fontFamily="Arial, sans-serif" fontSize="35" fontStyle="italic" fontWeight="800" letterSpacing="-1.8">travel</text>
        <text x="333" y="228" fill="#456F75" fontFamily="Arial, sans-serif" fontSize="10" fontWeight="700" letterSpacing="3">UNITED EXPRESS</text>
        <path d="M697 156L726 158L728 211H693Z" fill="#DAF6F5" opacity=".9"/>
        <path d="M714 177L728 177L728 207L715 209Z" fill="#FFF2C2"/>
        <path d="M58 213H75L75 238H57Z" fill="#E56D70"/>
        <path d="M41 255Q384 266 728 248" fill="none" stroke="#2D5862" strokeWidth="5"/>
        {[160, 582].map((x) => <g className="gt-bus-wheel" key={x} transform={`translate(${x},260)`}>
          <circle r="54" fill="#15242C"/><circle r="46" fill="#080E14" stroke="#2B3E43" strokeWidth="7"/><circle r="31" fill="#ABBEC2"/><circle r="22" fill="#5A7981" stroke="#CFE1E0" strokeWidth="3"/>
          <g className="gt-wheel-spokes">{[0,60,120].map((angle) => <path key={angle} d="M-22 0H22" stroke="#D8E7E6" strokeWidth="5" strokeLinecap="round" transform={`rotate(${angle})`}/>)}</g>
          <circle r="8" fill="#0B343F" stroke="#D8E7E6" strokeWidth="3" />
        </g>)}
        <path d="M705 134L729 146L742 166L727 170Z" fill="#D3EFEF"/>
        <path d="M717 138L745 154L738 163L714 155Z" fill="#164750"/>
        <rect x="93" y="44" width="95" height="9" rx="4.5" fill="#B8DADC" opacity=".8"/>
      </svg>
    </div></div>
    <div className="gt-speed-trails" aria-hidden="true" />
    <div className="gt-road-perspective" aria-hidden="true"><div className="gt-road-dashes" /></div>
    <div className="gt-route-badge" aria-hidden="true"><span>ITINÉRAIRE</span><strong>Yaoundé <b>→</b> Douala</strong></div>
    <div className="gt-visual-footer" aria-hidden="true"><span>TRANSIT · INTERURBAIN</span><span>VOYAGEZ. EXPLOREZ. ARRIVEZ.</span></div>
    <button className="gt-motion-toggle" type="button" disabled={reduced} title={reduced ? 'Animation désactivée par les préférences du système' : paused ? 'Reprendre l’animation' : 'Mettre en pause'} aria-label={reduced ? 'Animation désactivée par les préférences du système' : paused ? 'Reprendre l’animation du bus' : 'Mettre en pause l’animation du bus'} aria-pressed={paused} onClick={() => setPaused((value) => !value)}>{motionStopped ? <Play size={15} /> : <Pause size={15} />}</button>
  </div>
}
