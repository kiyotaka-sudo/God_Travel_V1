export function normalizeRole(role) {
  return role === 'CLIENT' ? 'ROLE_CLIENT' : role?.startsWith('ROLE_') ? role : `ROLE_${role || ''}`
}

export function isRoleAllowed(role, allowedRoles = []) {
  return allowedRoles.includes(normalizeRole(role))
}

export function safeInternalPath(value, fallback) {
  return typeof value === 'string' && value.startsWith('/') && !value.startsWith('//') && !value.includes('\\') ? value : fallback
}

export function normalizeCmPhone(value = '') {
  let digits = String(value).replace(/\D/g, '')
  if (digits.startsWith('237')) digits = digits.slice(3)
  return digits
}

export function isValidCmMobile(value) {
  return /^6\d{8}$/.test(normalizeCmPhone(value))
}

export function parseCmInstant(value) {
  if (!value) return Number.NaN
  const text = String(value)
  return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/i.test(text) ? text : `${text}+01:00`)
}

export function cashDifference(counted, theoretical) {
  return Number(counted || 0) - Number(theoretical || 0)
}

export function occupancyPercent(occupied, capacity) {
  const total = Number(capacity)
  if (!Number.isFinite(total) || total <= 0) return 0
  return Math.max(0, Math.min(100, (Number(occupied || 0) / total) * 100))
}

export function isSeatSelectable(seat, freeSeats, capacity) {
  const number = Number(seat)
  return Number.isInteger(number) && number > 0 && number <= Number(capacity) && freeSeats.has(number)
}

export function isTicketConfirmed(status) {
  return ['VALIDE', 'EMBARQUE'].includes(String(status || '').toUpperCase())
}

/** Retourne uniquement les voyages réservables et les trie par départ.
 * L'horloge et la disponibilité serveur sont réévaluées avant l'achat.
 */
export function getBookableTrips(trips, now = Date.now()) {
  if (!Array.isArray(trips)) return []
  return trips.filter((trip) => {
    if (!trip || !['PROGRAMME', 'OUVERT', 'CONFIRME'].includes(String(trip.statutVoyage || '').toUpperCase())) return false
    const departure = parseCmInstant(trip.dateHeureDepartPrevue)
    const seats = Number(trip.placesRestantes ?? 0)
    const capacity = Number(trip.capaciteTotale ?? 0)
    const price = Number(trip.tarifBaseXaf ?? 0)
    return Number.isFinite(departure) && departure > now
      && Number.isFinite(seats) && seats > 0
      && Number.isInteger(capacity) && capacity > 0
      && Number.isFinite(price) && price > 0
  }).sort((left, right) => parseCmInstant(left.dateHeureDepartPrevue) - parseCmInstant(right.dateHeureDepartPrevue))
}

/** Date locale du Cameroun (la date UTC du serveur ne correspond pas toujours au calendrier local). */
export function cameroonDateKey(value) {
  const timestamp = typeof value === 'number' ? value : parseCmInstant(value)
  if (!Number.isFinite(timestamp)) return ''
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Douala', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date(timestamp))
  const byType = Object.fromEntries(parts.map(({ type, value: part }) => [type, part]))
  return `${byType.year}-${byType.month}-${byType.day}`
}

/** Filtre la liste des voyages déjà contrôlés, sans modifier le tableau source. */
export function filterDepartures(trips, { route = '', date = '' } = {}) {
  if (!Array.isArray(trips)) return []
  return trips.filter((trip) => {
    const routeMatches = !route || `${trip.villeDepart} → ${trip.villeArrivee}` === route
    const dateMatches = !date || cameroonDateKey(trip.dateHeureDepartPrevue) === date
    return routeMatches && dateMatches
  })
}
