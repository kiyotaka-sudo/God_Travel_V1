import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const backend = (file) => readFileSync(new URL(`../../god-travel-backend/src/main/java/com/godtravel/backend/${file}`, import.meta.url), 'utf8')
const frontend = (file) => readFileSync(new URL(`../src/${file}`, import.meta.url), 'utf8')

test('recherche de billets : téléphone dans un POST et non une URL', () => {
  const server = backend('controller/BilletController.java')
  const client = frontend('api/index.js')
  assert.match(server, /@PostMapping\("\/consulter"\)/)
  assert.doesNotMatch(server, /@GetMapping\("\/consulter"\)/)
  assert.match(client, /api\.post\('\/billets\/consulter', \{ codeBillet, telephone \}\)/)
  assert.doesNotMatch(client, /api\.get\('\/billets\/consulter'/)
})

test('vérification Monetbil : téléphone dans un POST et non une URL', () => {
  const server = backend('controller/PaiementController.java')
  const client = frontend('api/index.js')
  assert.match(server, /@PostMapping\("\/monetbil\/statut"\)/)
  assert.match(client, /api\.post\('\/paiements\/monetbil\/statut', \{ reference, telephone \}\)/)
  assert.doesNotMatch(client, /api\.get\('\/paiements\/monetbil\/statut'/)
})

test('l’API ne révèle plus les détails techniques des exceptions non prévues', () => {
  const server = backend('exception/GlobalExceptionHandler.java')
  assert.match(server, /log\.error\("Erreur non gérée/)
  assert.doesNotMatch(server, /INTERNAL_ERROR", [^\n]*ex\.getMessage\(\)/)
})

test('un JWT existant ne peut pas activer un compte désactivé', () => {
  const server = backend('security/JwtAuthenticationFilter.java')
  assert.match(server, /userDetails\.isEnabled\(\)/)
  assert.match(server, /userDetails\.isAccountNonLocked\(\)/)
})


test('GPS : affectation du chauffeur, agence et balise associée au bus vérifiées', () => {
  const server = backend('service/GpsService.java')
  const repository = backend('repository/VoyageRepository.java')
  assert.match(server, /verifierHabilitation\(voyage\)/)
  assert.match(server, /countBalisePourBus/)
  assert.match(server, /countChauffeurAffecte/)
  assert.match(repository, /AFFECTER_EQUIPAGE/)
  assert.match(repository, /BALISE_GPS/)
})

test('GPS : les coordonnées et vitesses sont bornées par validation Jakarta', () => {
  const dto = backend('model/dto/gps/PointageGpsDto.java')
  assert.match(dto, /@DecimalMin\("-90\.0"\)/)
  assert.match(dto, /@DecimalMax\("90\.0"\)/)
  assert.match(dto, /@DecimalMin\("-180\.0"\)/)
  assert.match(dto, /@DecimalMax\("180\.0"\)/)
  assert.match(dto, /@Min\(0\)/)
})

test('identifiants générés par UUID pour les clients et positions GPS', () => {
  for (const path of ['service/GpsService.java', 'service/BilletterieService.java', 'service/ColisService.java']) {
    const server = backend(path)
    assert.doesNotMatch(server, /String idCli = "CLI-" \+ System\.currentTimeMillis\(\)/)
    assert.doesNotMatch(server, /String idPos = "POS-" \+ System\.currentTimeMillis\(\)/)
    assert.match(server, /UUID\.randomUUID\(\)/)
  }
})

test('l’API retourne un 409 pour un conflit SQL au lieu de divulguer une erreur', () => {
  const server = backend('exception/GlobalExceptionHandler.java')
  assert.match(server, /DataIntegrityViolationException/)
  assert.match(server, /HttpStatus\.CONFLICT/)
  assert.doesNotMatch(server, /DATA_CONFLICT", ex\.getMessage/)
})

test('documentation API réservée à ADMIN dans la configuration', () => {
  const server = backend('config/SecurityConfig.java')
  assert.match(server, /requestMatchers\("\/v3\/api-docs\/\*\*", "\/swagger-ui\/\*\*", "\/swagger-ui.html"\)/)
  assert.match(server, /\.hasRole\("ADMIN"\)/)
})


test('GPS : lecture et acquittement restreints à la bonne agence', () => {
  const server = backend('service/GpsService.java')
  assert.match(server, /String agence = agenceDeLecture\(\)/)
  assert.match(server, /agence\.equals\(pos\.getVoyage\(\)\.getAgence\(\)\.getIdAgence\(\)\)/)
  assert.match(server, /agence\.equals\(alerte\.getVoyage\(\)\.getAgence\(\)\.getIdAgence\(\)\)/)
  assert.match(server, /alerte\.setEstAcquittee\(true\)/)
})
