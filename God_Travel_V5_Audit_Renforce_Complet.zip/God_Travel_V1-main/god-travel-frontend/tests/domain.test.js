import test from 'node:test'
import assert from 'node:assert/strict'
import { cameroonDateKey, filterDepartures, cashDifference, getBookableTrips, isRoleAllowed, isSeatSelectable, isTicketConfirmed, isValidCmMobile, normalizeCmPhone, normalizeRole, occupancyPercent, parseCmInstant, safeInternalPath } from '../src/utils/domain.js'

test('normalise les téléphones camerounais sans retirer le préfixe mobile', () => {
  assert.equal(normalizeCmPhone('+237 699 00 00 00'), '699000000')
  assert.equal(isValidCmMobile('+237 699 00 00 00'), true)
  assert.equal(isValidCmMobile('299000000'), false)
  assert.equal(isValidCmMobile('69900000'), false)
})

test('calcule l’écart entre le comptage physique et le total théorique', () => {
  assert.equal(cashDifference(12_500, 10_000), 2_500)
  assert.equal(cashDifference(8_000, 10_000), -2_000)
})

test('limite le taux d’occupation à une capacité valide et à 100 %', () => {
  assert.equal(occupancyPercent(24, 60), 40)
  assert.equal(occupancyPercent(80, 60), 100)
  assert.equal(occupancyPercent(0, 0), 0)
})

test('un siège n’est sélectionnable que s’il est libre et dans la capacité du bus', () => {
  const free = new Set([1, 7, 12])
  assert.equal(isSeatSelectable(7, free, 60), true)
  assert.equal(isSeatSelectable(8, free, 60), false)
  assert.equal(isSeatSelectable(61, free, 60), false)
})

test('seuls les billets confirmés par le backend sont valides à consulter', () => {
  assert.equal(isTicketConfirmed('VALIDE'), true)
  assert.equal(isTicketConfirmed('EMBARQUE'), true)
  assert.equal(isTicketConfirmed('EN_ATTENTE_PAIEMENT'), false)
  assert.equal(isTicketConfirmed('ANNULE'), false)
})

test('lit les heures sans fuseau comme une heure locale du Cameroun (UTC+1)', () => {
  assert.equal(parseCmInstant('2026-11-18T08:30:00'), Date.parse('2026-11-18T07:30:00Z'))
  assert.equal(parseCmInstant('2026-11-18T08:30:00Z'), Date.parse('2026-11-18T08:30:00Z'))
})

test('normalise les rôles client et respecte les rôles autorisés par une route', () => {
  assert.equal(normalizeRole('CLIENT'), 'ROLE_CLIENT')
  assert.equal(normalizeRole('ADMIN'), 'ROLE_ADMIN')
  assert.equal(isRoleAllowed('ROLE_CLIENT', ['ROLE_CLIENT']), true)
  assert.equal(isRoleAllowed('ROLE_CLIENT', ['ROLE_ADMIN']), false)
})

test('la destination de connexion reste interne à l’application', () => {
  assert.equal(safeInternalPath('/app/caisse?jour=1', '/app'), '/app/caisse?jour=1')
  assert.equal(safeInternalPath('//example.com', '/app'), '/app')
  assert.equal(safeInternalPath('https://example.com', '/app'), '/app')
  assert.equal(safeInternalPath('/\\\\example.com', '/app'), '/app')
})

test('filtre les départs passés, complets, non ouverts et trie les départs futurs', () => {
  const trip = (idVoyage, dateHeureDepartPrevue, statutVoyage = 'PROGRAMME', placesRestantes = 10, tarifBaseXaf = 4500, capaciteTotale = 60) => ({ idVoyage, dateHeureDepartPrevue, statutVoyage, placesRestantes, tarifBaseXaf, capaciteTotale })
  const trips = [
    trip('futur2', '2026-11-25T10:00:00'),
    trip('passe', '2026-11-18T10:00:00'),
    trip('complet', '2026-11-24T10:00:00', 'PROGRAMME', 0),
    trip('annule', '2026-11-24T10:00:00', 'ANNULE'),
    trip('futur1', '2026-11-24T10:00:00', 'OUVERT'),
  ]
  assert.deepEqual(getBookableTrips(trips, Date.parse('2026-11-19T00:00:00Z')).map(({ idVoyage }) => idVoyage), ['futur1', 'futur2'])
  assert.deepEqual(getBookableTrips(null), [])
})


test('ne présente pas les trajets sans bus affecté ou tarif actif', () => {
  const date = '2027-01-02T12:30:00'
  const now = Date.parse('2027-01-01T00:00:00Z')
  const valid = { idVoyage: 'valid', dateHeureDepartPrevue: date, statutVoyage: 'OUVERT', placesRestantes: 30, capaciteTotale: 60, tarifBaseXaf: 4500 }
  assert.deepEqual(getBookableTrips([valid, { ...valid, idVoyage: 'no-price', tarifBaseXaf: 0 }, { ...valid, idVoyage: 'no-bus', capaciteTotale: null }, { ...valid, idVoyage: 'bad-price', tarifBaseXaf: -100 }], now).map(t => t.idVoyage), ['valid'])
})

test('la recherche de départ ne modifie pas la liste reçue du serveur', () => {
  const now = Date.parse('2027-01-01T00:00:00Z')
  const items = Object.freeze([
    Object.freeze({ idVoyage: 'z', dateHeureDepartPrevue: '2027-02-05T12:00:00', statutVoyage: 'OUVERT', placesRestantes: 2, capaciteTotale: 50, tarifBaseXaf: 5000 }),
    Object.freeze({ idVoyage: 'a', dateHeureDepartPrevue: '2027-02-04T12:00:00', statutVoyage: 'OUVERT', placesRestantes: 1, capaciteTotale: 50, tarifBaseXaf: 5000 }),
  ])
  assert.deepEqual(getBookableTrips(items, now).map(t => t.idVoyage), ['a', 'z'])
  assert.equal(items[0].idVoyage, 'z')
})

test('rejette les formats de téléphone invalides pour un suivi public', () => {
  assert.equal(isValidCmMobile('+237 655 00 11 22'), true)
  assert.equal(isValidCmMobile('123456789'), false)
  assert.equal(isValidCmMobile('699-hello-00'), false)
})


test('les filtres de départ respectent la date locale du Cameroun', () => {
  const list = Object.freeze([
    Object.freeze({ idVoyage: 'a', villeDepart: 'Yaoundé', villeArrivee: 'Douala', dateHeureDepartPrevue: '2027-05-03T00:30:00' }),
    Object.freeze({ idVoyage: 'b', villeDepart: 'Douala', villeArrivee: 'Yaoundé', dateHeureDepartPrevue: '2027-05-03T10:30:00' }),
    Object.freeze({ idVoyage: 'c', villeDepart: 'Yaoundé', villeArrivee: 'Douala', dateHeureDepartPrevue: '2027-05-04T11:00:00' }),
  ])
  assert.equal(cameroonDateKey('2027-05-02T23:30:00Z'), '2027-05-03')
  assert.deepEqual(filterDepartures(list, { route: 'Yaoundé → Douala', date: '2027-05-03' }).map(x => x.idVoyage), ['a'])
  assert.deepEqual(filterDepartures(list, { date: '2027-05-04' }).map(x => x.idVoyage), ['c'])
  assert.deepEqual(filterDepartures(list, {}).map(x => x.idVoyage), ['a', 'b', 'c'])
  assert.deepEqual(filterDepartures(null, {}), [])
})

test('une date absente ou invalide ne provoque pas de plantage', () => {
  assert.equal(cameroonDateKey(null), '')
  assert.equal(cameroonDateKey('pas une date'), '')
  assert.deepEqual(filterDepartures([{ villeDepart: 'A', villeArrivee: 'B', dateHeureDepartPrevue: null }], { date: '2027-05-03' }), [])
})
