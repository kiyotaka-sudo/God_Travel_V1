> **ATTENTION :** `database/schema_production.sql` est un script d'**initialisation destructive** : il contient des `DROP TABLE`. Ne l'importez jamais sur une base déjà utilisée. Pour les mises à jour, utilisez une sauvegarde et une migration vérifiée.

> **Édition V4 du 19 novembre 2026.** Changements et vérifications : [`RAPPORT_GOD_TRAVEL_V4.md`](RAPPORT_GOD_TRAVEL_V4.md). Historique : [`RAPPORT_REFONTE_GOD_TRAVEL.md`](RAPPORT_REFONTE_GOD_TRAVEL.md). Installation Windows et publication GitHub : [`GUIDE_PUBLICATION_GITHUB.md`](GUIDE_PUBLICATION_GITHUB.md). CI : `.github/workflows/ci.yml`. Veille dépendances : `.github/dependabot.yml`.

# God Travel

Plateforme de réservation et d’exploitation de voyages interurbains : espace client, billetterie, gestion des billets et outils d’agence.

## Technologies

- Backend : Java 17+, Spring Boot, Spring Security, JPA et Maven
- Frontend : React, Vite, Leaflet et React Three Fiber
- Base : MySQL / MariaDB, schéma master `god_travel_complet_master.sql`

## Contenu du dépôt

- `god-travel-backend/` : API et règles métier
- `god-travel-frontend/` : interface client et espace équipe
- `god_travel_complet_master.sql` : schéma et données fictives pour démonstration locale (aucun compte prédéfini)
- `database/schema_production.sql` : tables, vues et procédures sans données d’exemple pour une première installation vide
- `database/migrations/V3__booking_index_and_availability.sql` : migration des installations anciennes, à appliquer après sauvegarde

La base MariaDB active, les identifiants locaux, les `.bat`, les dépendances installées et les runtimes Windows ne sont pas versionnés.

## Configuration

1. Installez Java 17 ou plus récent, Maven, Node.js et MySQL/MariaDB.
2. Choisissez le script SQL : `god_travel_complet_master.sql` pour une **démo locale avec données fictives**, ou `database/schema_production.sql` pour un **schéma initial vide**. Les deux scripts suppriment et recréent les tables : **sauvegardez la base et ne les importez jamais sur une installation contenant des données à conserver**. Pour une base V1/V2 existante, voir la migration V3 séparée.
3. Copiez `god-travel-backend/src/main/resources/application.example.properties` vers `application.properties` au même endroit, puis configurez l’accès à la base.
4. Configurez les secrets localement, sans les ajouter au dépôt : `APP_JWT_SECRET` et `APP_TICKET_HMAC_SECRET` doivent chacun contenir au moins 32 caractères. Pour le premier administrateur, définissez `APP_BOOTSTRAP_ADMIN_PASSWORD` (12 caractères minimum) et éventuellement `APP_BOOTSTRAP_ADMIN_LOGIN` ; le profil ADMIN et l’employé `EMP-001` doivent déjà être présents. La démo inclut ces références sans compte utilisable ; avec le schéma vide, l’exploitant doit d’abord créer ses propres données de compagnie, agence, profil et employé.
5. Pour les paiements en ligne, ajoutez `MONETBIL_SERVICE_KEY`, `MONETBIL_SERVICE_SECRET` et une URL HTTPS publique dans `MONETBIL_PUBLIC_BASE_URL` pour recevoir les notifications Monetbil. Configurez aussi `GOD_TRAVEL_FRONTEND_URL` et `APP_CORS_ALLOWED_ORIGINS` avec le vrai domaine HTTPS, sans wildcard. **Supprimez le secret d’amorçage de l’environnement après la création du compte**, puis changez le mot de passe via un canal administrateur sécurisé.

Exemple de génération de secrets dans PowerShell :

```powershell
$env:APP_JWT_SECRET = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$env:APP_TICKET_HMAC_SECRET = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
$env:APP_BOOTSTRAP_ADMIN_PASSWORD = Read-Host 'Mot de passe initial administrateur'
```

## Lancement

Backend, depuis `god-travel-backend/` :

```powershell
mvn spring-boot:run
```

Frontend, depuis `god-travel-frontend/` :

```powershell
npm.cmd ci
npm.cmd run dev
```

Vite sert l’interface sur `http://localhost:5173` et relaie les requêtes API vers le backend sur `http://localhost:8080/api`.

## Parcours principaux

- Les voyageurs créent un compte distinct des comptes équipe, consultent les départs réellement ouverts, choisissent un siège et paient depuis la page de réservation.
- Après validation de la notification Monetbil par le backend, le billet et son QR signé sont consultables dans « Mes billets » ou avec le code billet et le téléphone. L’impression est prévue depuis ces deux parcours.
- L’accueil affiche une illustration animée du bus et une scène 3D pilotée par le défilement avec une version statique pour le mouvement réduit ou l’absence de WebGL, puis les horaires, des filtres par itinéraire et date, la carte Leaflet et les services. Les départs se réactualisent lorsque la page reste visible et l’animation du bus s’arrête hors écran.
- L’espace équipe sépare les opérations disponibles selon le rôle : billetterie, caisse, colis, GPS, maintenance et administration. Les opérations sans API sont signalées au lieu d’être simulées.
- L’interface existe en thèmes clair et sombre, en français, avec des formats de dates `Africa/Douala` et des montants XAF.

## Vérifications frontend

Depuis `god-travel-frontend/` :

```powershell
npm.cmd run lint
npm.cmd test
npm.cmd run build
```

Le proxy local se règle avec `god-travel-frontend/.env` (copiez `.env.example`). Le client HTTP du navigateur appelle `/api`; il ne contient pas d’URL de backend.

## Capacités à compléter côté backend

- Le paiement Monetbil doit être configuré avec une clé de service et un secret de notification valides. Les notifications signées et les parcours de réconciliation/remboursement doivent être validés avec le fournisseur avant toute vente réelle. Le frontend ne peut pas confirmer un paiement si la notification signée n’arrive pas au backend.
- L’API ne propose pas encore la retenue temporaire de siège, l’idempotence serveur, la recherche avancée, la réservation de groupe, le consentement enregistré, les packs/fidélité, les règles de promotion, les profils et les workflows opérationnels hôtesse/chauffeur, ni plusieurs informations demandées pour le billet. Les écarts détaillés figurent dans `BACKEND_GAPS.md`.
- Le jeton JWT reste persisté dans `localStorage`, comme dans l’architecture existante ; le frontend ne change pas le mécanisme d’authentification. En revanche, le backend refuse désormais l’accès aux comptes désactivés, même avec un JWT non expiré.
- La vérification publique des billets et des paiements se fait par POST (plus de téléphone dans les URL) ; les anciens clients qui utilisaient le GET doivent être mis à jour vers V4.
- La limitation de tentatives intégrée est **locale à un serveur**. Une production derrière plusieurs instances exige une passerelle ou un compteur partagé (Redis, WAF), en tenant compte de la configuration du proxy et de l’IP source.

## Règles de mise en production V3

- Le backend et MySQL sont alignés sur le fuseau `Africa/Douala` ; ne pas supprimer cette configuration tant que les dates métier restent en `LocalDateTime`.
- Le code est **préparé pour GitHub**, pas certifié pour recevoir des paiements réels. Exécuter `npm ci && npm run lint && npm test && npm run build` puis `mvn test` et les scénarios MySQL/Monetbil sur un environnement de recette.
- Le compte initial est créé uniquement si `APP_BOOTSTRAP_ADMIN_PASSWORD` est renseigné **et** les référentiels administrateur existent. Aucun mot de passe de démonstration ne doit être conservé.
- Dans les anciennes bases importées avec les identifiants V1, **désactiver/faire tourner immédiatement les comptes par défaut** ; la migration V3 ne change pas leurs mots de passe.
- Le paiement confirmé d’un colis ne signifie pas « parti » : le personnel enregistre physiquement le départ. Les annulations de billets déjà encaissés nécessitent un processus de remboursement non implémenté ; elles sont refusées.
- Le tarif affiché est le tarif **adulte en vigueur**, sans promesse de réduction enfant/étudiant tant que le moteur tarifaire spécifique n’est pas développé.
- Les règles de confidentialité, les tests de concurrence, la protection anti-abus (suivi public/login), les webhooks et la résilience des paiements restent des prérequis pour une exploitation réelle.
