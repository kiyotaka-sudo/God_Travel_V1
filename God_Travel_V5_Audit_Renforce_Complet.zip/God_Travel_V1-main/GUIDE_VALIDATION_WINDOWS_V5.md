# God Travel V5 — Valider sur Windows et intégrer dans GitHub

## Décompresser et ouvrir

Extraire le ZIP. Ouvrir **le dossier intérieur** `God_Travel_V1-main` dans Visual Studio Code : il doit contenir directement `god-travel-frontend`, `god-travel-backend`, `database`, `README.md`.

## Terminal 1 : frontend

```powershell
cd god-travel-frontend
node --version
npm.cmd ci
npm.cmd test
npm.cmd run lint
npm.cmd run build
npm.cmd run dev
```

Ouvrir l'adresse Vite indiquée, généralement `http://localhost:5173`. `npm.cmd` permet d'éviter les blocages `npm.ps1` de PowerShell. Si les dépendances ne sont pas installées, les builds ne sont **pas** validés.

## Terminal 2 : backend

Installer **Java JDK 17+** et **Maven**, puis, depuis le dossier racine :

```powershell
cd god-travel-backend
java -version
mvn.cmd -version
mvn.cmd test
mvn.cmd package
```

Les tests Java des autorisations GPS et du limiteur sont inclus dans cette étape. Si `mvn.cmd` n'est pas reconnu, installer Maven et ajouter son dossier `bin` au `PATH`.

Copier `src/main/resources/application.example.properties` dans `src/main/resources/application.properties` et définir une base **de test** et des secrets appropriés. Les instructions de configuration sont dans le `README.md`.

**Ne jamais** importer `database/schema_production.sql` dans une base contenant des données : il exécute `DROP TABLE` et efface les données. En cas de doute, créer une base MySQL temporaire distincte et conserver une sauvegarde vérifiée.

## Contrôles fonctionnels obligatoires

- Voyageurs : inscription, connexion, départs, sélection et expiration de siège, billet payé, affichage du QR.
- Agent : réservation en caisse, clôture de caisse, agences séparées, colis du dépôt à la remise.
- GPS : le chauffeur non affecté doit être refusé ; une balise d'un autre bus doit être refusée ; un chef d'agence ne doit pas accéder aux alertes d'une autre agence.
- Paiement : tester les signatures, doublons, montants erronés, retards et remboursements **uniquement en environnement Monetbil de recette**.
- Mobile : vérifier 360 px, 768 px et écran large ; faire défiler l'animation 3D, puis activer la réduction de mouvement.

## Publication GitHub

L'archive V5 contient les **sources** ; ne pas envoyer `node_modules` ni les fichiers `.env` ou `application.properties` contenant des secrets. Dans `https://github.com/kiyotaka-sudo/God_Travel_V1`, ajouter/remplacer le **contenu du dossier intérieur** `God_Travel_V1-main`, pas le ZIP lui-même. Préférer une nouvelle branche ou une Pull Request, exécuter les tests CI, puis fusionner si les validations sont vertes.

Aucun push n'a été effectué par l'assistant. Le projet **n'est pas certifié pour l'exploitation commerciale** tant que les étapes du rapport V5 n'ont pas été réalisées.
